package chap06;

class Rectangle{
	int width;
	int height;
	
	Rectangle(int width , int height){
		this.width = width;
		this.height = height;
	}
	
	public void area() {
		System.out.println(this.width * this.height);
	}
	public void length() {
		System.out.println(this.width*2 + this.height*2);
	}
}

public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r1 = new Rectangle(10,5);
		Rectangle r2 = new Rectangle(30,20);
		
		r1.area();
		r1.length();
		
		r2.area();
		r2.length();
	}

}

package chap06;

public class FactorialEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("4! = " + factorial(4));
	}
	private static int factorial(int i) {
		
		System.out.println(i);
		if(i != 1) {
			i = i * factorial(i-1);
			return i;
		}else {
			return 1;
		}
		
	}

}

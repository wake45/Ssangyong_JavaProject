package chap06;

class Rectangle2{
	int width;
	int height;
	int serialNo;
	static int sno;
	
	Rectangle2(int width, int height){
		this.width = width;
		this.height = height;
	}
	
	public int area() {
		return width*height;
	}
	public int length() {
		return width*2 + height*2;
	}
	public String toString() {
		return "���� " + width + " �ѷ� " + height;
	}
}

public class Exam4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int width = 10;
		int height = 20;
		int area = 0;
		int length = 0;
		Rectangle2 r[] = new Rectangle2[3];
		for(int i = 0 ; i < r.length ; i++) {
			r[i] = new Rectangle2(width,height);
			width += 5; height += 5;
			area += r[i].area();
			System.out.println("���� : " + r[i].area());
			length += r[i].length();
			System.out.println("�ѷ� : " + r[i].length());	
		}
		
		System.out.println("��ü ���� : " + area);
		System.out.println("��ü �ѷ� : " + length);
	}

}

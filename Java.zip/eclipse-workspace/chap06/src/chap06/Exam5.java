package chap06;

class Animal{
	String name;
	int age;
	
	Animal(String name, int age){
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Animal [name=" + name + ", age=" + age + "]";
	}
}

public class Exam5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a = new Animal("������",26);
		System.out.println(a);
	}	

}

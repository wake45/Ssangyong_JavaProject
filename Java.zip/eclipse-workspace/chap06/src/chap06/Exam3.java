package chap06;

class Card1{
	static int width = 40;
	static int height =40;
	String kind;
	int number;
	
	Card1(String kind , int number){
		this.kind = kind;
		this.number = number;
	}
	
	@Override
	public String toString() {
		return "Card1 [kind=" + kind + ", number=" + number + ", width=" + width + ", height=" + height + "]";
	}
}


public class Exam3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Card1 c1 = new Card1("Heart",1);
		System.out.println(c1);
		
		Card1 c2 = new Card1("Spade",1);
		System.out.println(c2);
		
		Card1.width = 50 ; Card1.height = 80;
				
		System.out.println(c1);
		System.out.println(c2);
	}

}

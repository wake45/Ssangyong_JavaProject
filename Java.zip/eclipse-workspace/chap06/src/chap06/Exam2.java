package chap06;

public class Exam2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r[] = new Rectangle[3];
		
		int width = 10;
		int height = 20;
		for(int i = 0 ; i < r.length ; i++) {
			r[i] = new Rectangle(width++,height++);

			r[i].area();
			r[i].length();
		}
		
	}

}

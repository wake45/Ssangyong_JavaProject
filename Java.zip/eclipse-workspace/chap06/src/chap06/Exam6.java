package chap06;

class Circle{
	int r;
	int x;
	int y;
	int no;
	static int count = 0;
	final double pi = 3.14;
	
	Circle(int r, int x, int y){
		this.r = r;
		this.x = x;
		this.y = y;
		this.no = count++;
	}
	Circle(int x, int y){
		this.x = x;
		this.y = y;
		this.no = count++;
	}
	Circle(int r){
		this.r = r;
		this.no = count++;
	}
	
	public double area() {
		return 2*pi*this.r;
	}
	public double length() {
		return pi*this.r*this.r;
	}
	public void move(int a,int b) {
		this.x += a;
		this.y += a;
		this.y += b;
	}
	public void scale(double m) {
		this.r *= m;
	}
	@Override
	public String toString() {
		return "Circle [r=" + r + ", x=" + x + ", y=" + y + ", no=" + no + "]";
	}

}

public class Exam6 {
	public static void main(String args[]) {
		Circle[] carr = new Circle[3];
		carr[0] = new Circle(10,10,10);
		carr[1] = new Circle(20,20);
		carr[2] = new Circle(100);
		for(Circle c : carr) {
			System.out.println(c);
			c.move(10, 10);
			System.out.println(c);
			c.scale(3);
			System.out.println(c);
		}
	}
}

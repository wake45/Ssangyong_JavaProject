package chap04;

public class Exam16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int first = 1;
		int second = 1;
		int result = 0;
		
		System.out.print(first + "," + second);
		while(first + second < 1000) {
			result = first + second;
			first = second;
			second = result;
			
			System.out.print("," + result);
		}
	}

}

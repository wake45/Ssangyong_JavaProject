package chap04;

import java.util.Scanner;

public class Exam3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("���� �Է� : ");
		int num = sc.nextInt();
		
		if(num%4==0) {
			if(num%100==0) {
				if(num%400==0) {
					System.out.println("����");
				}
				else {
					System.out.println("���");
				}
			}
			else {
				System.out.println("����");
			}
		}
		else {
			System.out.println("���");
		}
		
		if((num%400==0) || ((num%4==0) && (num%100!=0))) {
			System.out.println("����");
		}
		else {
			System.out.println("���");
		}
	}

}

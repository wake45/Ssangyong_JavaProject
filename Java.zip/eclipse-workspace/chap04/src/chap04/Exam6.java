package chap04;

import java.util.Scanner;

public class Exam6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("���ڿ� �Է� : ");
		String str = sc.next();
		
		System.out.println("���ڿ� ���� : " + str.length());
		
		for(int i = 0 ; i < str.length() ; i++) {
			System.out.print(str.charAt(i) + " ");
		}
		
		int sum=0;
		for (int i = 0 ; i < str.length() ; i++) {
			sum = str.charAt(i)-48;
		}
		System.out.println(sum);
		
	}

}

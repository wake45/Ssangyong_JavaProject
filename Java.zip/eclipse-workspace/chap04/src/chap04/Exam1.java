package chap04;

import java.util.Scanner;

public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("���� �Է� : ");
		int num = sc.nextInt();
		
		if(num > 0) {
			System.out.println("��");
		}else if(num == 0) {
			System.out.println("0");
		}else {
			System.out.println("��");
		}
	}

}

package chap04;

import java.util.Scanner;

public class Exam5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("�ڿ��� �Է� : ");
		int num = sc.nextInt();
		int i = 1;
		int cnt = 0;
		//�ڸ��� Ȯ��
		while(num != 0){
			if(num/i !=0) {
				cnt++;
				i *= 10;
				continue;
			}
			else {
				break;
			}	
		}
		
		int sum = 0;
		int temp;
		for(int j = 1 ; j <= cnt ; j++) {
			temp = 1;
			for(int k = 1 ; k <= cnt-j ; k++) {
				temp *= 10;
			}
			sum += num/temp;
			num = num - ((num/temp)*temp);
		}
		
		System.out.println(sum);
	}

}

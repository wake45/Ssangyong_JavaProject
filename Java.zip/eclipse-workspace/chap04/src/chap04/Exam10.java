package chap04;

import java.util.Scanner;

public class Exam10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("�ﰢ�� ���� �Է� : ");
		int num = sc.nextInt();
		
		for(int i = 1 ; i <= num ; i++) {
			for(int j = 0 ; j <= num-i ; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}

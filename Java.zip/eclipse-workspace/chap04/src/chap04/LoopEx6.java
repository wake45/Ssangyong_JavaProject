package chap04;

import java.util.Scanner;

public class LoopEx6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int sum = 0;
		int cnt = 0;
		System.out.println("���ڸ� �Է��ϼ���(����:99999) : ");
		
		while(true) {
			int num = sc.nextInt();
			if(num==99999)break;
			cnt++;
			sum += num;
		}
		System.out.println("���� : " + sum);
		System.out.println("��� : " + (double)sum/cnt);
	}

}

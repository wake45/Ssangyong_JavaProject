package chap04;

import java.util.Scanner;

public class Exam14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("���� �Է� : ");
		int num = sc.nextInt();
		int result = 0;
		int cnt = 1; //�ڸ���

		int tmp = num;
		while(tmp >= 1) {
			if((tmp/10) != 0) {
				cnt++;
			}
			tmp /= 10;
		}
		
		int tmp_cnt = cnt;
		tmp = num;
		while(cnt != 0) {
			
			int num_digit = 1;
			int res_digit = 1;
			
			for(int j = 1 ; j < tmp_cnt ; j++) {
				res_digit *= 10;
			}
			
			for(int j = 1 ; j < cnt ; j++) {
				num_digit *= 10;
			}
		
			res_digit /= num_digit;
			result += (tmp/num_digit)*res_digit;
			tmp = tmp-((tmp/num_digit)*num_digit);
			cnt--;
		}
		
		
		if(num == result) {
			System.out.println("��Ī�� �Դϴ�.");
		}else {
			System.out.println("��Ī���� �ƴմϴ�.");
		}
		
		//������
		//while(temp!=0){
		//result*=10;
		//result+=temp%10;
		//temp/=10; }
	}

}

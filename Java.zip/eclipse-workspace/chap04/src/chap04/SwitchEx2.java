package chap04;

public class SwitchEx2 {
	public static void main(String[] args) {

		int value = 1; 
		
		switch(value/10){ //int���� ����
			case 1: System.out.println(value); break;
			case 2: System.out.println(value); break;
			default: System.out.println(value); break;
		}
	}
}

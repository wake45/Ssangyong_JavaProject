package chap04;

import java.util.Scanner;

public class Exam13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("�ﰢ�� ���� �Է� : ");
		int num = sc.nextInt();
		
		for(int i = 1 ; i <= num ; i++) {
			for(int j  = 0 ; j < num ; j++) {
				if(j<num-i) {
					System.out.print(" ");
				}
				else{
					System.out.print("*");
				}
			}
			for(int j = 1 ; j < i ; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}

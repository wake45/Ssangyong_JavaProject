package chap12;

class NewClass{
	int newField;
	int getNewField() { return newField; }
	@Deprecated
	int oldField;
	@Deprecated
	int getOldField() { return oldField; }
}

public class AnnotationEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NewClass nc = new NewClass();
		nc.oldField = 10;
		System.out.println(nc.getOldField());
	}

}

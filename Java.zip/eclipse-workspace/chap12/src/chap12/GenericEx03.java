package chap12;

class Product<T,M>{
	private T kind;
	private M Model;
	
	public T getKind() {
		return this.kind;
	}

	public M getModel() {
		return Model;
	}

	public void setModel(M model) {
		Model = model;
	}

	public void setKind(T kind) {
		this.kind = kind;
	}
}
class Car{}
class Tv{}
public class GenericEx03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product<Tv,String> product1 = new Product<Tv,String>();
		product1.setKind(new Tv());
		product1.setModel("����Ʈ TV");
		Tv tv = product1.getKind();
		String tvModel = product1.getModel();
		Product<Car,String> product2 = new Product<Car,String>();
		product2.setKind(new Car());
		product2.setModel("����");
		Car car = product2.getKind();
		String carModel = product2.getModel();
	}

}

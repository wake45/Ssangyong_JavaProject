package chap11;

import java.util.*;

public class Exam3 {
	public static void main(String args[]) {
		System.out.println("�ζ� ��ȣ");
		Set<Integer> ball = new TreeSet<>();
		while(ball.size() < 6) {
			ball.add((int)(Math.random()*45)+1);
		}
		System.out.println(ball);
	}
}

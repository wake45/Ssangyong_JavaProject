package chap11;

import java.util.*;


class Person2 implements Comparable<Person2>{
	String name;
	int age;
	public Person2(String name, int age) {
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return name + "=" + age;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		Person2 p = (Person2)obj;
		return name.equals(p.name) && age==p.age;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return name.hashCode()+age;
	}
	@Override
	public int compareTo(Person2 o) {
		// TODO Auto-generated method stub
		return hashCode() - o.hashCode();
		//		return o.age-age; //���̼� ����
//		return name.compareTo(o.name); //�̸��� ����
	}
	
}
public class SetEx6 {
public static void main(String[] args) {
	Set<Person2> set = new TreeSet<Person2>();
	set.add(new Person2("ȫ�浿",10));
	set.add(new Person2("ȫ�浿",10));
	set.add(new Person2("ȫ�浿",30));
	set.add(new Person2("������",16));
	set.add(new Person2("������",20));
	Person2 p1 = new Person2("���",25);
	set.add(p1);
	System.out.println(set);
}
}

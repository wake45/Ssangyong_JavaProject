package chap11;

import java.util.*;

public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Ȧ ���� ���� �Է� (���� :-1)");
		List<Integer> list = new ArrayList<Integer>();
		int sum = 0 ; //��
		while(true) {
			int temp = sc.nextInt();	
			if(temp == -1) {
				list.add(temp);
				break;
			}
			else list.add(temp);
		}
		
		int temp = list.indexOf(-1)/2;
		System.out.println("�߾� �� : " + list.get(temp));
		
		for(int i = 0 ; i < list.size()-1 ; i++) {
			sum += list.get(i);
		}
		System.out.println("�� : " + sum);
	}

}

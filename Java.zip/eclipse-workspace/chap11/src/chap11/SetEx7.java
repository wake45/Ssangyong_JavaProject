package chap11;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Person3{
	String name;
	int age;
	public Person3(String name, int age) {
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return name + "=" + age;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		Person3 p = (Person3)obj;
		return name.equals(p.name) && age==p.age;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return name.hashCode()+age;
	}
	
	
}
public class SetEx7 {
public static void main(String[] args) {
	List<Person3> li = new ArrayList<Person3>();
	li.add(new Person3("ȫ�浿",10));
	li.add(new Person3("ȫ�浿",10));
	li.add(new Person3("ȫ�浿",30));
	li.add(new Person3("������",16));
	li.add(new Person3("������",20));
	Person3 p1 = new Person3("���",25);
	li.add(p1);
	System.out.println(li);
	
	Collections.sort(li, new Comparator<Person3>(){
		public int compare(Person3 o1, Person3 o2) {
			return (o1.age-o2.age)*-1;
		}
	});
	System.out.println(li);
}
}

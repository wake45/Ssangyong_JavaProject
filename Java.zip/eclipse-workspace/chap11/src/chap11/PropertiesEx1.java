package chap11;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesEx1 {
	public static void main(String args[]) throws IOException {
		Properties pr = new Properties();
		System.out.println(pr);
		FileInputStream fis = new FileInputStream("src/chap11/a.properties");
		pr.load(fis);
		System.out.println(pr);
		System.out.println("�̸� : " + pr.getProperty("name"));
		System.out.println("��ȭ��ȣ : " + pr.getProperty("tel"));
		pr.put("subject", "��ǻ�Ͱ���");
		System.out.println(pr);
		FileOutputStream fos = new FileOutputStream("src/chap11/b.properties");
		pr.store(fos, "#save");
	}
}

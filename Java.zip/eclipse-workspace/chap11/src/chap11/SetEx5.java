package chap11;

import java.util.*;

class Person implements	Comparable<Person>{
	String name;
	int age;
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return name + "=" + age;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		Person p = (Person)obj;
		return name.equals(p.name) && age==p.age;
	}
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return name.hashCode()+age;
	}
	@Override
	public int compareTo(Person o) {
		// TODO Auto-generated method stub
		return age-o.age; //���̼� ����
//		return name.compareTo(o.name); //�̸��� ����
	}
	
}
public class SetEx5 {
public static void main(String[] args) {
	List<Person> li = new ArrayList<Person>();
	li.add(new Person("ȫ�浿",10));
	li.add(new Person("ȫ�浿",10));
	li.add(new Person("ȫ�浿",30));
	li.add(new Person("������",16));
	li.add(new Person("������",20));
	Person p1 = new Person("���",25);
	li.add(p1);
	System.out.println(li);
	Collections.sort(li);
	System.out.println(li);
}
}
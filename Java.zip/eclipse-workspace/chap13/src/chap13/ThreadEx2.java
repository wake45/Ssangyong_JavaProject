package chap13;

class Runnable1 implements Runnable{
	public void run() {
		for(int i = 0 ; i < 5 ; i++) {
			System.out.println(i + "=" + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			}catch(InterruptedException e) {}
		}
	}
}

public class ThreadEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("������ ����");
		Runnable r = new Runnable1();
		Thread t1 = new Thread(r,"First");
		Thread t2 = new Thread(r,"Second");
		t1.start(); t2.start();
		System.out.println("main ������ ����~");
	}

}

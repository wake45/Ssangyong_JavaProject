package chap13;

class SumThread extends Thread{
	int start;
	int last;
	int sum;
	
	SumThread(int s, int l){
		this.start = s;
		this.last = l;
	}
	public void run() {
		for(int i = start; i <= last ; i++) {
			sum+=i;
		}
		System.out.printf("%d���� %d������ �� : %d%n",start,last,sum);
	}
}

public class Exam1 {
	public static void main(String args[]) throws InterruptedException {
		SumThread t1 = new SumThread(1,100);
		SumThread t2 = new SumThread(101,200);
		SumThread t3 = new SumThread(201,300);
		SumThread t4 = new SumThread(301,400);
		SumThread t5 = new SumThread(401,500);
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		
		t1.join(); t2.join(); t3.join(); t4.join(); t5.join();
		System.out.println("1����500������ �� : " + (t1.sum+t2.sum+t3.sum+t4.sum+t5.sum));
	}
}

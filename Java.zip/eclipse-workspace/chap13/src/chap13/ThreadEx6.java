package chap13;

class ATM implements Runnable{
	private int money = 100000;
	public void run() {
		while(true) {
			try {
				Thread.sleep((int)(Math.random()*1000));
			}catch(InterruptedException e) {
				
			}
			if(money <= 0) break;
			withdraw();
		}
		
	}
	void withdraw() {
		if(money <= 0) return;
		money -= 10000;
		System.out.println(Thread.currentThread().getName() + " ���. �ܾ� : " + money);
	}
}

public class ThreadEx6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ATM atm = new ATM();
		Thread son = new Thread(atm,"SON");
		Thread daughter = new Thread(atm,"DAUGHTER");
		son.start(); daughter.start();
	}

}

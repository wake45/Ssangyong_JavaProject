package TeamProject;

import java.io.*;
import java.util.*;

public class Register {

	UserInfo user = new UserInfo();

	@SuppressWarnings("resource")

	public void signUp(String id, String pw, String name) {
		FileWriter fw;
		Scanner sc = new Scanner(System.in);

		try {
			fw = new FileWriter(new File("src/TeamProject/MemberList.txt"), true); // ȸ�������� ȸ�� ������ MemberList.txt�� ���

			this.user.setId(id);
			this.user.setPw(pw);
			this.user.setName(name);

			fw.write(this.user.toRegister() + "\r\n");
			fw.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
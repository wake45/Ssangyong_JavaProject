package TeamProject;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

class Sender extends Thread {
	Socket socket;
	DataOutputStream out;
	String name;
	boolean chk = true;

	Sender(Socket socket, boolean chk) {
		this.socket = socket;
		this.chk = chk;
		try {
			out = new DataOutputStream(socket.getOutputStream());
			name = ":";
		} catch (Exception e) {
		}
	}

	public void run() {
		Scanner scanner = new Scanner(System.in);
		while (out != null) {

			try {
				
				String temp = scanner.nextLine();
				if (temp.equals("��")) {
					chk = false;
					System.out.println("=========������ ������ ���������ϴ�=========");
					Project.main(null);
				}

				else {
					out.writeUTF(name + temp);
				}
				
				

			} catch (IOException e) {
			} catch (Exception e) {
			}
		}
		

		scanner.close();
	
	}
	
}

class Receiver extends Thread {
	Socket socket;
	DataInputStream in;

	Receiver(Socket socket) {
		this.socket = socket;

		try {
			in = new DataInputStream(socket.getInputStream());
		} catch (IOException e) {
		}

	}

	public void run() {
		while (in != null) {
			
			try {

				System.out.println(in.readUTF());
				
			} catch (IOException e) {
			}
		}
	}

}

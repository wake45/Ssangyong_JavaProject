package TeamProject;

import java.io.*;


class SendToServer {
	BufferedReader in;

	SendToServer(String menu, String ID, String pwd, String name, PrintWriter out) {
		out.println(menu + ":" + ID + ":" + pwd + ":" + name);
		out.flush();
	}

	SendToServer(String menu, String ID, String pwd, PrintWriter out) {
		out.println(menu + ":" + ID + ":" + pwd);
		out.flush();
	}
	

}

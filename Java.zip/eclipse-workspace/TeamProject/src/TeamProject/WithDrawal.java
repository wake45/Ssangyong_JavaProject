package TeamProject;

import java.io.*;
import java.util.*;


public class WithDrawal {
	/*
	String id;
	String pw;
	*/
	@SuppressWarnings("resource")
	public int withDrawal(String id,String pw) throws Exception {
		Map<String, UserInfo> map = new HashMap<String, UserInfo>();
		Scanner sc = new Scanner(System.in);
		FileReader fr;
		
			fr = new FileReader(new File("src/TeamProject/MemberList.txt"));
			BufferedReader br = new BufferedReader(fr);
		
			br.lines().forEach(s->{
				String[] str = s.split(",");
				map.put(str[0], new UserInfo(str[0],str[1],str[2]) );
			});
		
		if(map.containsKey(id)) {
			if(map.get(id).getPw().equals(pw)) {
				map.remove(id);
				
				BufferedWriter writer = new BufferedWriter(new FileWriter("src/TeamProject/MemberList.txt"));
				
				for (String i : map.keySet()) {
					writer.write(map.get(i).toRewrite() + "\r\n");
				}
				writer.close();
				br.close();
				return 1;
			}
			
			else {
				br.close();
				return 0 ;
			}
		}
		else {
			br.close();
			return -1;
		}
	
	}
	
}

package TeamProject;

import java.io.*;
import java.net.*;


public class ChatClient {
	boolean chk=true;
	BufferedReader in;
	PrintWriter out;
	
	public void chat() {
		try {
			String serverIp = "localhost";			
			Socket socket = new Socket(serverIp,7777);
			Sender sender = new Sender(socket, chk);
			Receiver receiver = new Receiver(socket);
			sender.start();
			receiver.start();
		
		}
		catch(ConnectException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
				
	}
	


}


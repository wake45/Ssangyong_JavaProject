package TeamProject;

import java.io.*;
import java.net.*;

public class Server {

	public static void main(String args[]) throws IOException {
		ServerSocket server = new ServerSocket(8000);

		while (true) {
			System.out.println("Ŭ���̾�Ʈ ���� �����");
			Socket client = server.accept();
			new EchoServerThread(client).start();
		}
		
	}

}

class EchoServerThread extends Thread {
	Socket client;
	PrintWriter out;
	BufferedReader in;
	

	EchoServerThread(Socket client) {
		this.client = client;
		try {
			out = new PrintWriter(client.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(client.getInputStream()));

		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("client ip : " + client.getInetAddress() + ":" + client.getPort());
	}

	public void sendClient(String input) throws Exception {
		String menu[] = input.split(":");

		Register register = new Register();
		LoginCheck loginCheck = new LoginCheck();
		WithDrawal with = new WithDrawal();

		switch (menu[0]) {
		case "menu1":
			register.signUp(menu[1], menu[2], menu[3]);
			out.println("��ȸ�������� ���ϵ帳�ϴ٢�");

			break;
		case "menu2":
			int login = loginCheck.menu2(menu[1], menu[2]);
			// -1 ���̵�Ʋ�� 0 ���Ʋ�� 1����
			System.out.println(login);
			out.println("�α��� ����!:" + login);
			break;
		case "menu4":
			int getout = with.withDrawal(menu[1], menu[2]);
			out.println("ȸ��Ż�� ����!:" + getout);
			break;
		}
		out.flush();
	}
	


	public void run() {
		System.out.println("������");
		String input = "";
		try {
			
			while((input = in.readLine()) !=null) {
				System.out.println("client msg : " + input);
				sendClient(input);
			}
	/*		
			BufferedReader studin = new BufferedReader(new InputStreamReader(System.in));
			
			while ((input = in.readLine()) != null) {
				
				if(input.contains(".")) {
				System.out.println("���� : " + input);
				System.out.print("���亯: ");
				msg = studin.readLine();
				out.println(msg);
				out.flush();
		}
				else {
					sendClient(input);
				}
			}
			*/

		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				in.close();
				out.close();
				client.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * String printString() { String s = ""; for(Product p : li ) { s+=p.toTxt(); }
	 * return s; }
	 * 
	 * 
	 * String printString(String name) { String s = ""; for(Product p : li) {
	 * if(p.toTxt().contains(name)) s+= p.toTxt(); } return s; }
	 */
}
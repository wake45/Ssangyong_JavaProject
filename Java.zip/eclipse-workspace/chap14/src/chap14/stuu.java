package chap14;
import java.util.Comparator;

class stuu implements Comparable<stuu>{
	private String name;
	private int ban;
	private int eng;
	private int math;
	public stuu(String name, int ban, int eng, int math, int kor) {
		this.name = name;
		this.ban = ban;
		this.eng = eng;
		this.math = math;
		this.kor = kor;
		this.score = eng+math+kor;
	}
	@Override
	public String toString() {
		return "stuu [name=" + name + ", ban=" + ban + ", eng=" + eng + ", math=" + math + ", kor=" + kor + ", score="
				+ score + "]";
	}
	private int kor;
	private int score;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBan() {
		return ban;
	}
	public void setBan(int ban) {
		this.ban = ban;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	@Override
	public int compareTo(stuu s) {
		return (s.eng+s.math+s.kor) - (eng+math+kor);
	}
}
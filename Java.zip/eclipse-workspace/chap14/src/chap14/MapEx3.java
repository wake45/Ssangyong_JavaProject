package chap14;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class MapEx3 {
	public static void main(String[] args) throws FileNotFoundException {
		BufferedReader br = new BufferedReader(new FileReader("product.txt"));
		br.lines().map(s->{
			String str[] = s.split(",");
			String temp = "";
			try {
				temp = str[4];
			}catch(ArrayIndexOutOfBoundsException e) {
				temp = "";
			}
			
			return new Car(Integer.parseInt(str[0]),Integer.parseInt(str[1]),str[2],Integer.parseInt(str[3]),temp);
			
		}).filter(s->s.getCar().equals("�׷���")).forEach(c->System.out.println(c.getCar()));
	}
}
class Car{
	private int month;
	private int con;
	private String car;
	private int qty;
	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getCon() {
		return con;
	}

	public void setCon(int con) {
		this.con = con;
	}

	public String getCar() {
		return car;
	}

	public void setCar(String car) {
		this.car = car;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	private String remark;
	
	public Car(int month,int con,String car,int qty,String remark) {
		super();
		this.month =month;
		this.con = con;
		this.car = car;
		this.qty = qty;
		this.remark = remark;
	}
}
package chap14;

public class LamdaEx2 {
	public static void main(String[] args) {
		System.out.println("main start");
		Runnable r = () -> {
			int sum = 0;
			for (int i = 0; i < 100; i++) {
				sum += i;
			}
			System.out.println("1~100 sum1 : " + sum);
		};

		Thread t = new Thread(r);
		Thread t2 = new Thread(() -> {
			int sum = 0;
			for (int i = 0; i < 100; i++) {
				sum += i;
			}
			System.out.println("*****1~100 sum 2 : " + sum);
		});
		t.start(); //���� ���� ������� ��?
		t2.start();
		System.out.println("main exit");
	}
}

class Aaa implements Runnable {
	@Override
	public void run() {

	}
}

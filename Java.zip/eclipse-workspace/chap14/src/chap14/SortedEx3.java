package chap14;

import java.util.Comparator;
import java.util.stream.Stream;

public class SortedEx3 {
	public static void main(String args[]) {
		Stream<stuu> studentStream = Stream.of(
				new stuu("ȫ�浿",1,89,56,66),
				new stuu("���",1,85,88,80),
				new stuu("�̸���",2,90,78,95),
				new stuu("�Ӳ���",3,60,56,88),
				new stuu("�Ӳ���",1,90,73,73));
		
		studentStream.sorted(Comparator.comparing(stuu::getBan).thenComparing(Comparator.naturalOrder())).forEach(System.out::println);		
	}
}

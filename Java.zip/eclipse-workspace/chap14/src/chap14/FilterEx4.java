package chap14;

import java.util.Arrays;
import java.util.List;
/*
public class FilterEx4 {
	public static void main(String args[]) {
		List<Member> list = Arrays.asList(
				new Member("ȫ�浿",Member.MALE,30),
				new Member("�質��",Member.FEMALE,20),
				new Member("�ſ��",Member.MALE,45),
				new Member("�ڼ���",Member.FEMALE,27));
		//double ageAvg = list.stream().filter(m ->m.getSex()==Member.MALE).mapToInt(Member::getAge).average().getAsDouble();
		//System.out.println("������ճ��� : " + ageAvg);
		list.stream().filter(m -> m.getSex() == Member.MALE).mapToInt(Member::getAge).forEach(s->System.out.println(s));
	}
}
class Member{
	public static int MALE = 0;
	public static int FEMALE = 1;
	public String name;
	private int sex;
	private int age;
	public Member(String name,int sex,int age) {
		this.name = name;
		this.sex = sex;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
*/
package chap14;

import java.util.function.*;

public class LamdaEx7 {
	public static void main(String[] args) {
		Supplier<String> s1 = () -> "java";
		System.out.println(s1.get()); 

		IntSupplier s2 = () -> (int) (Math.random() * 6) + 1;
		System.out.println("�ֻ��� : " + s2.getAsInt()); //getInt -> ��Ʈ���� ���

		DoubleSupplier s3 = () -> {
			double d = Math.random();
			return d;
		};
		System.out.println("������ �Ǽ� : " + s3.getAsDouble());
	}
}

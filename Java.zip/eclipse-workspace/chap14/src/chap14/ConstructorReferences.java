package chap14;

import java.util.function.BiFunction;
import java.util.function.*;

public class ConstructorReferences {
	public static void main(String[] args) {
		Function<String, Membe> function1 = Membe::new; //������ ����
		Membe member = function1.apply("angel");

		BiFunction<String, String, Membe> function2 = Membe::new;
		Membe member2 = function2.apply("��õ��", "angerl");

	}
}
class Membe {
	String name;
	String id;

	public Membe() {
		System.out.println("Member() ����");
	}

	public Membe(String id) {
		System.out.println("Member(String id) �����");
		this.id = id;
	}

	public Membe(String name, String id) {
		System.out.println("Member(String name, String id) �����");
		this.name = name;
		this.id = id;
	}
}

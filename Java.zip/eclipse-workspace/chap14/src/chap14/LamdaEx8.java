package chap14;

import java.util.function.*;

public class LamdaEx8 {
	private static Student1[] list = { new Student1("ȫ�浿", 90, 80, "�濵"), new Student1("���", 95, 70, "�İ�") };

	public static void main(String[] args) {
		System.out.print("�л��� �̸� : ");
		printString(t -> t.getName());
		System.out.print("���� �̸� : ");
		printString(t -> t.getMajor());
		System.out.println("========================");
		Function<Student1, String> f2 = t -> t.getName();//??
		printString(f2);
		printString(new Function<Student1, String>() {
			@Override
			public String apply(Student1 t) {
				return t.getName();
			}
		});

		System.out.print("���� ���� : ");
		printInt(t -> t.getEng());
		System.out.print("���� ���� : ");
		printInt(t -> t.getMath());
		System.out.print("���� ���� �հ� : ");
		printTot(t -> t.getEng());
		System.out.print("���� ���� �հ� : ");
		printTot(t -> t.getMath());
		System.out.print("���� ��� : ");
		printAvg(t -> t.getEng()); 
 		System.out.print("���� ��� : ");
		printAvg(t -> t.getMath());
		
		//�հ�� ����� ���� ���� ���غ���
		//�� �Ʒ��� ������
		
	}
		
	//ToIntFunction ToDoubleFunction
	//applyAsInt applyAsDouble
	//Function
	//apply
	private static void printInt(ToIntFunction<Student1> f) { // printInt(Function<String, Integer> f)
		for (Student1 s : list) {
			System.out.print(f.applyAsInt(s) + ","); // ??
		}
		System.out.println();
	}

	private static void printString(Function<Student1, String> f) {
		for (Student1 s : list) {
			System.out.print(f.apply(s) + ","); //�޼ҵ� ���� apply
		}
		System.out.println();
	}
	
	private static void printTot(ToIntFunction<Student1> f) {
		int sum = 0;
		for(Student1 s : list) {
			sum += f.applyAsInt(s);
		}
		System.out.println(sum);
	}
	private static void printAvg(ToDoubleFunction<Student1> f) {
		int sum = 0;
		int cnt = 0;
		for(Student1 s : list) {
			sum += f.applyAsDouble(s);
			cnt++;
		}
		System.out.println(sum/(double)cnt);
	}
	
	
	
}

class Student1 {
	private String name;
	private int eng;
	private int math;
	private String major;

	public Student1(String name, int eng, int math, String major) {
		// TODO Auto-generated constructor stub
		this.name = name;
		this.eng = eng;
		this.math = math;
		this.major = major;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

}

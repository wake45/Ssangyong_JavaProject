package chap14;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ProductGroup {
	public static void main(String[] args) throws FileNotFoundException {
		BufferedReader br = new BufferedReader(new FileReader("product.txt"));
		Stream<Car1> car1 = br.lines().map(s->{
			String str[] = s.split(",");
			String temp = "";
			try {
				temp = str[4];
			}catch(ArrayIndexOutOfBoundsException e) {
				temp = "";
			}
			
			return new Car1(Integer.parseInt(str[0]),Integer.parseInt(str[1]),str[2],Integer.parseInt(str[3]),temp);
			
		});

		/*
		Map<Integer,List<Car1>> map = car1.collect(Collectors.groupingBy(s->s.getMonth()));
		System.out.println(map);
		
		for(Map.Entry<Integer, List<Car1>> e:map.entrySet()) {
			System.out.println(e.getKey());
			for(Car1 c : e.getValue()) {
				System.out.println(c);
			}
		}*/
		
		//Map<Integer,Long> map2 = car1.collect(Collectors.groupingBy(Car1::getMonth,Collectors.counting()));
		//for(Map.Entry<Integer,Long>e:map2.entrySet()){
		//	System.out.println(e.getKey() + "�� : " + e.getValue() );
		//}
		
		Map<Integer,Integer> map4 = car1.filter(s->s.getCon() == 1).collect(Collectors.groupingBy(s->s.getMonth(),Collectors.summingInt(Car1::getQty)));
		System.out.println("���� ���� ����");
		for(Map.Entry<Integer, Integer> e:map4.entrySet()) {
			System.out.println(e.getKey() + " �� : " + e.getValue());
		}
	}
}
class Car1{
	private int month;
	private int con;
	private String car1;
	private int qty;
	public Car1(int month,int con,String car1,int qty,String remark) {
		this.month =month;
		this.con = con;
		this.car1 = car1;
		this.qty = qty;
		this.remark = remark;
	}
	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getCon() {
		return con;
	}

	public void setCon(int con) {
		this.con = con;
	}

	public String getCar1() {
		return car1;
	}

	public void setCar(String car1) {
		this.car1 = car1;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	@Override
	public String toString() {
		return "Car1 [month=" + month + ", con=" + con + ", car1=" + car1 + ", qty=" + qty + ", remark=" + remark + "]";
	}

	private String remark;
	
	 
}
package chap14;

import java.util.Arrays;
import java.util.List;

public class ReductionExample {
	public static void main(String args[]) {
		List<Stu> sl = Arrays.asList(
				new Stu("ȫ�浿",92),
				new Stu("�ſ��",95),
				new Stu("���ڹ�",88));
		int sum1 = sl.stream().mapToInt(Stu::getScore).sum();
		int sum2 = sl.stream().map(Stu::getScore).reduce((a,b)-> a + b).get();
		int sum3 = sl.stream().map(Stu::getScore).reduce(1, (a,b)->a*b);
		
		System.out.println("sum1 " + sum1);
		System.out.println("sum2 " + sum2);
		System.out.println("sum3 " + sum3);
	}
}
class Stu{
	private String name;
	private int score;
	public Stu(String name,int score) {
		this.name = name;
		this.score = score;
	}
	public String getName() {
		return name;
	}
	public int getScore() {
		return score;
	}
}

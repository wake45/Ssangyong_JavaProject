package chap14;

import java.util.*;
import java.util.stream.Stream;

public class FlatMapEx3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stream<String[]> strArrStrm = Stream.of(
				new String[] {"abc","def","jkl"},
				new String[] {"ABC","GHI","JKL"});
		Stream<String> stream = strArrStrm.flatMap(Arrays::stream);
		stream.forEach(s -> System.out.println(s));
	}

}

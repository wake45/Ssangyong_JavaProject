package chap14;

import java.util.function.*;

public class PredicateAndOrNegate {
	public static void main(String[] args) {
		IntPredicate predicateA = a -> a % 2 == 0;

		IntPredicate predicateB = (a) -> a % 3 == 0;

		IntPredicate predicateAB;
		boolean result;
//and
		predicateAB = predicateA.and(predicateB);
		result = predicateAB.test(9);
		System.out.println("9�� 2�� 3�� ���?> " + result);
//or
		predicateAB = predicateA.or(predicateB);
		result = predicateAB.test(9);
		System.out.println("9�� 2�Ǵ� 3�� ���?> " + result);
//negate
		predicateAB = predicateA.negate();
		result = predicateAB.test(9);
		System.out.println("9�� Ȧ��? " + result);

	}
}

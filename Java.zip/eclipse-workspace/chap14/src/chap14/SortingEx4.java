package chap14;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;

public class SortingEx4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntStream intStream = Arrays.stream(new int[] {5,3,2,1,4});
		intStream.sorted().forEach(n-> System.out.print(n + ","));
		System.out.println();
		List<stuu> studentList = Arrays.asList(
				new stuu("ȫ�浿",1,89,56,66),
				new stuu("���",1,85,88,80),
				new stuu("�̸���",2,90,78,95));
		System.out.println("default : ");
		studentList.stream().sorted().forEach(s->System.out.print(s.getScore() + ","));
		System.out.println();
		System.out.println("reverse : ");
		studentList.stream().sorted(Comparator.reverseOrder()).forEach(s->System.out.print(s.getScore() + ","));
	}

}

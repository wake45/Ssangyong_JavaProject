package chap14;

public class LamdaEx5 {
	public static void main(String[] args) {

		Outer o = new Outer();
		o.method();
	}
}
interface LamdaInterface5 {
	void method();
}
class Outer {
	public int iv = 10;

	void method() { // ��ü�� = () -> {} // final�� �������� �ʾƵ� �ڵ������
		final int iv = 40;
		LamdaInterface5 f5 = () -> {
			//iv = 50;
			System.out.println("Outer.this.iv = " + Outer.this.iv);
			System.out.println("this. iv = " + this.iv); //?????
			System.out.println("iv = " + iv);
		};
		f5.method();
	}
}
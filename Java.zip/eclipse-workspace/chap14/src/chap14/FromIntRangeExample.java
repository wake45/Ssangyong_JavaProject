package chap14;

import java.util.stream.*;

public class FromIntRangeExample {
	public static int sum;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntStream stream = IntStream.rangeClosed(1, 100);//�������� ������
		stream.forEach(a->sum+=a);
		System.out.println("���� : " + sum);
		
		sum = 0;
		stream = IntStream.range(1, 100); 
		stream.forEach(a -> sum += a);
		
		System.out.println("���� : " + sum);
	}

}

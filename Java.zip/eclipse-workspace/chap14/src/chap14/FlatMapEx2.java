package chap14;

import java.util.*;

public class FlatMapEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> studentList1 = Arrays.asList(
				new Student("ȫ�浿",10),new Student("������",20),
				new Student("���ϵ�",30));
		
		List<Student> studentList2 = Arrays.asList(
				new Student("���ڹ�",10),new Student("�ſ��",20),
				new Student("���̼�",30));
		List<List<Student>> stu = new ArrayList<List<Student>>();
			stu.add(studentList1);
			stu.add(studentList2);
			
		//stu.forEach(score -> System.out.println(score.get(?));
		stu.stream().flatMap(s->s.stream()).forEach(score -> System.out.println(score.getName() + " " + score.getScore()));
		//��Ʈ�������� ��
		}

}

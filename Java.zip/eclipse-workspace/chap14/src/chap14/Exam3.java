package chap14;

import java.util.function.IntBinaryOperator;

public class Exam3 {
	private static int[] arr = new int[10];

	public static void main(String[] args) {
		for (int i = 0; i < arr.length; i++) {
			arr[i] = (int) (Math.random() * 100);
		}

		System.out.println();
		System.out.println("�ִ밪" + maxOrMin((a, b) -> (a <= b) ? b : a));
		System.out.println("�ּҰ�" + maxOrMin((a, b) -> (a <= b) ? a : b));
	}

	private static int maxOrMin(IntBinaryOperator op) {
		int result = arr[0];
		for (Object arr : arr) {
			result = op.applyAsInt(result, (int) arr);
		}
		return result;
	}
}

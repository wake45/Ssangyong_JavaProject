package chap14;

public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LamdaEx11 f = x -> {
			int sum = 0;
			for (int j = 1; j <= x; j++) {
				sum += j;
			}
			System.out.println("1���� " + x + "������ �� : " + sum);
		};

		f.method(10);
		f.method(100);
	}

}
interface LamdaEx11 {
	void method(int num);

}


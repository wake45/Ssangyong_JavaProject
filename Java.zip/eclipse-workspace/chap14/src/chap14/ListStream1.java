package chap14;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ListStream1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> list = Arrays.asList(
				new Student("ȫ�浿",90),
				new Student("�ſ��",92)
		);
		
		Stream<Student> stream = list.stream();
		stream.forEach(g -> {
			String name = g.getName();
			int score = g.getScore();
			System.out.println(name + "-" + score);
		});
	}
}

class Student{
	private String name;
	private int score;
	
	Student(String name,int score){
		this.name = name;
		this.score = score;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}

}
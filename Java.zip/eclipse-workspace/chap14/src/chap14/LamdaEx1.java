package chap14;

public class LamdaEx1 {

	public static void main(String[] args) {
		//�پ��� ��ĵ�
		
		LamdaInterface1 fi = new LamdaInterface1() {
			@Override
			public void method() {
				System.out.println("����������� �ڵ�");
			}
		};
		fi.method();

		fi = () -> {
			String str = "method call1";
			System.out.println(str);
		};
		fi.method();

		fi = () -> {
			System.out.println("method call2");
		};
		fi.method();
		
		fi = () -> {
			System.out.println("method call3");
		};
		fi.method();
		
		fi=()-> System.out.println("method call4");
		fi.method();
		
		execute(()->System.out.println("method call5"));
		//???
	}
	static void execute(LamdaInterface1 f){
		f.method();
	}
}

interface LamdaInterface1 {
	void method();
}


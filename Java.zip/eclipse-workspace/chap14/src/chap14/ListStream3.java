package chap14;

import java.util.*;
import java.util.stream.Stream;

public class ListStream3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = Arrays.asList("ȫ�浿","�ô���","���ڹ�","���ٽ�","�ٺ���");
		Stream<String> stream = list.parallelStream();
		stream.forEach(ListStream3::print);
		
		System.out.println();
		Stream<String> parallelStream  = list.parallelStream();
		parallelStream.forEach(ListStream3::print); // ListStream3 �� print �޼ҵ� ����
	}
	public static void print(String str) {
		System.out.println(str +" : " + Thread.currentThread().getName());
	}
	//parallelStream
	//currentThread
}

package chap14;

import java.util.*;
import java.util.stream.*;

public class CollectEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		stuu[] stuArr = {
			new stuu("���ڹ�",3,34,55,80),
			new stuu("���ڹ�",1,60,45,90),
			new stuu("���ڹ�",2,80,95,60),
			new stuu("���ڹ�",2,75,85,70),
			new stuu("���ڹ�",1,65,65,90),
			new stuu("���ڹ�",3,60,85,50),
			new stuu("���ڹ�",3,40,75,60)
		};
		
		List<String> names = Stream.of(stuArr).map(stuu::getName).collect(Collectors.toList());
		System.out.println(names);
		
		stuu[] stuArr2 = Stream.of(stuArr).toArray(stuu[]::new);
		for(stuu s : stuArr2) System.out.println(s);
		
		Map<String,stuu> stuMap = Stream.of(stuArr).collect(Collectors.toMap(s->s.getName(),p->p));
		for(String name : stuMap.keySet())
			System.out.println(name + "-" + stuMap.get(name));
		
		long count = Stream.of(stuArr).collect(Collectors.counting());
		long totalScore = Stream.of(stuArr).collect(Collectors.summingInt(stuu::getScore));
		System.out.println("count = " + count);
		System.out.println("totalScore = " + totalScore);
		
		totalScore = Stream.of(stuArr).collect(Collectors.reducing(0,stuu::getScore,Integer::sum));
		System.out.println("totalScore = " + totalScore);
		
		Optional<stuu> topStudent = Stream.of(stuArr).collect(Collectors.maxBy(Comparator.comparingInt(stuu::getScore)));
		System.out.println("toStudent" + topStudent.get());
		
		IntSummaryStatistics stat = Stream.of(stuArr).collect(Collectors.summarizingInt(stuu::getScore)); //�հ� ��� �ּڰ�ó�� �������� �����ö� ��� != summingInt
		System.out.println(stat);
		String stuNames = Stream.of(stuArr).map(stuu::getName).collect(Collectors.joining(",","{","}"));
		System.out.println(stuNames);
	}

}

package chap10;

import java.util.Calendar;

public class CalendarEx6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int year = 2020;
		int month[] = new int[12];
		for(int i = 0 ; i < month.length ; i++) {
			month[i] = i+1;
		}
		
		int START_DAY_OF_WEEK1 = 0;
		int START_DAY_OF_WEEK2 = 0;
		int START_DAY_OF_WEEK3 = 0;
		
		int END_DAY1 = 0;
		int END_DAY2 = 0;
		int END_DAY3 = 0;
		
		Calendar sDay1 = Calendar.getInstance(); //getInstance?
		Calendar eDay1 = Calendar.getInstance();
		Calendar sDay2 = Calendar.getInstance(); //getInstance?
		Calendar eDay2 = Calendar.getInstance();	
		Calendar sDay3 = Calendar.getInstance(); //getInstance?
		Calendar eDay3 = Calendar.getInstance();
				
		for(int i = 0 ; i < month.length ; i+=3) {
			int cal2 = 1;
			int cal3 = 1;
						
			sDay1.set(year,month[i]-1,1); // 1,4,7,10
			eDay1.set(year,month[i],1);
			sDay2.set(year,month[i+1]-1,1); // 2,5,8,11
			eDay2.set(year,month[i+1],1);
			sDay3.set(year,month[i+2]-1,1); // 3,6,9,12
			eDay3.set(year,month[i+2],1);
			
			eDay1.add(Calendar.DATE, -1); 
			START_DAY_OF_WEEK1 = sDay1.get(Calendar.DAY_OF_WEEK); 
			END_DAY1 = eDay1.get(Calendar.DATE); 
			
			eDay2.add(Calendar.DATE, -1);
			START_DAY_OF_WEEK2 = sDay2.get(Calendar.DAY_OF_WEEK); 
			END_DAY2 = eDay2.get(Calendar.DATE);
			
			eDay3.add(Calendar.DATE, -1); 
			START_DAY_OF_WEEK3 = sDay3.get(Calendar.DAY_OF_WEEK); 
			END_DAY3 = eDay3.get(Calendar.DATE);
			
			System.out.print("\t" + year + "�� " + month[i] + "��");
			System.out.print("\t\t" + year + "�� " + month[i+1] + "��");
			System.out.println("\t\t" + year + "�� " + month[i+2] + "��");
			
			System.out.print(" SU MO TU WE TH FR SA");
			System.out.print("\t SU MO TU WE TH FR SA");
			System.out.println("\t SU MO TU WE TH FR SA");
			
			boolean first1 = true; boolean first2 = true; boolean first3 = true;
			int n_cal2 = START_DAY_OF_WEEK2;
			int n_cal3 = START_DAY_OF_WEEK3;
			
			for(int j1 = 1, n1 = START_DAY_OF_WEEK1 ; j1 <= END_DAY1+7 ; j1++,n1++) {
				
				if(first1 == true) {
					for(int j = 1 ; j < START_DAY_OF_WEEK1; j++) {
						System.out.print("   ");
					}
					first1 =false;
				}
				if(j1 <= END_DAY1) {
					System.out.print((j1<10)? "  " + j1 : " " + j1);
				}
				if((n1%7!=0 && j1 == END_DAY1) || j1>END_DAY1) {
					int temp = n1;
					while(true) {
						System.out.print("   ");
						n1++;
						if(n1%7 == 0) {
							//n1 = temp;
							break;
						}
					}
				}
				if(n1%7==0 || j1 == END_DAY1) { 
					System.out.print("\t"); //7���Ǹ� ����
					if(first2 == true) {
						for(int j = 1 ; j < START_DAY_OF_WEEK2; j++) {
							System.out.print("   ");	
						}
						first2 =false;
					}
					for(int j2 = cal2, n2 = n_cal2 ; j2 <= END_DAY2+7 ; j2++,n2++) {					
						if(j2 <= END_DAY2) {
							System.out.print((j2<10)? "  " + j2 : " " + j2);
						}
						if((n2%7!=0 && j2 == END_DAY2) || j2 > END_DAY2) {
							while(true) {
								System.out.print("   ");
								n2++;
								if(n2%7 == 0) {
									break;
								}
							}
						}
						if(n2%7==0 || j2 == END_DAY2) {//7���� �ٹٲ�
							System.out.print("\t"); //7���Ǹ� ����
							if(first3 == true) {
								for(int j = 1 ; j < START_DAY_OF_WEEK3; j++) {
									System.out.print("   ");
								}
								first3 = false;
							}
							for(int j3 = cal3, n3 = n_cal3 ; j3 <= END_DAY3+7 ; j3++,n3++) {
								if(j3 <= END_DAY3) {
									System.out.print((j3<10)? "  " + j3 : " " + j3);
								}
								if((n3%7!=0 && j3 == END_DAY3) || j3 > END_DAY3) {
									while(true) {
										System.out.print("   ");
										n3++;
										if(n3%7 == 0) {
											break;
										}
									}
								}
								if(n3%7==0 || j3 == END_DAY3) { 
									System.out.println(); //7���� �ٹٲ�
									cal3 = ++j3;
									n_cal3 = ++n3;
									break;
								}
							}
							cal2 = ++j2;
							n_cal2 = ++n2;
							break;
						}			
					}			
				}
			}
		}
	}
}

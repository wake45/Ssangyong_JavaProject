package chap10;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class CalendarEx3 {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		System.out.println("ù��° ��¥�� �Է��ϼ���(yyyy-MM-dd)");
		Scanner sc = new Scanner(System.in);
		String first = sc.nextLine();
		System.out.println("�ι�° ��¥�� �Է��ϼ���(yyyy-MM-dd)");
		String second = sc.nextLine();
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
		Date fdate = sf.parse(first);
		Date sdate = sf.parse(second);
		
		long datecnt = (sdate.getTime() - fdate.getTime())/(1000*60*60*24);
		System.out.printf("%s-%s ������ ���� : %d\n",second,first,datecnt);
	}
	

}

package test;

public class OopEx1_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Food chicken = new Food("ġŲ",18000);
		Food pizza = new Food("����",28000);
		Food sushi = new Food("�ʹ似Ʈ",22000);
		
		Food[] foods = {chicken,pizza,sushi};
		
		for(int i = 0 ; i < foods.length;i++) {
			System.out.println(foods[i].toString());
		}
	}
}

class Food{
	String food;
	int price;
	
	Food(String food, int price){
		this.food = food;
		this.price = price;
	}
	
	public String toString() {
		return "food : " + food + ", price : " + price;
	}
}

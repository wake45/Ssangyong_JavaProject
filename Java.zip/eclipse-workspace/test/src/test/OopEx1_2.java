package test;

public class OopEx1_2 {
	public static void main(String args[]) {
		Dog d = new Dog();
		
		System.out.printf("�̸� : %s\n", d.name);
		System.out.printf("ǰ�� : %s\n", d.breeds);
		System.out.printf("���� : %s\n", d.age);
	}
}

class Dog{
	String name;
	String breeds;
	int age;
}
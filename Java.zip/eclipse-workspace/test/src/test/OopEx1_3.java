package test;

public class OopEx1_3 {
	public static void main(String args[]) {
			Cylinder c = new Cylinder();
			
			c.radius = 4;
			c.height = 5;
			
			System.out.printf("������� ���� : %.2f\n",c.getVolume());
			System.out.printf("������� �ѳ��� : %.2f\n",c.getArea());
		}
	}
class Cylinder{
		int radius;
		int height;
		
	public double getVolume() {
		return (radius*radius*Math.PI)*height;
	}
	public double getArea() {
		return 2*Math.PI*radius*height + 2*Math.PI*radius*radius; 
	}
}
package test;

import java.io.IOException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;


public class test {
	
	public static void main(String[] args) throws IOException {	
		
		//Scanner sc = new Scanner(System.in);
		//System.out.println("���� �Է� : ");
		//int num = sc.nextInt();

		/* �� ������ ������
		for (int i = 1; i <= 9; i++) {
			for (int j = 1; j <= 3; j++) {
				int x = j + 1 + (i - 1) / 3 * 3;
				int y = i % 3 == 0 ? 3 : i % 3;
				if (x > 9)
					break;

				System.out.print(i + "*" + y + "=" + i * y + "\t");
			}
			System.out.println();
			if (i % 3 == 0)
				System.out.println(); //
		}
		
		System.out.println(Integer.MAX_VALUE);
		
		int arr[] = new int[10];
		System.out.println(arr[]);
		*/
		
		/*
		String name = "�̻��";
		int age = 26;
		int height = 189;
		int weight = 85;
		String msg = "���̸� : " + name + 
				"\n ���� : " + age +
				"\n Ű : " + height +
				"\n ������  : " + weight;
		JOptionPane.showMessageDialog(null, msg, "������", JOptionPane.INFORMATION_MESSAGE);
		*/
		/*
		Set<Integer> set = new HashSet<>();
		
		for(int i = 0 ; i < 3 ; i++) {
			set.add((int)(Math.random()*10)+1);
		}
		Iterator it2 = (Iterator) set.iterator();
		while(it2.hasNext()) {
			System.out.println(it2.next());
		}
		*/
		for(int i = 0 ; i < 0 ; i++) {
			System.out.println("�̰� �����ǳ�?");
		}
	}
}
	


package test;

public class OopEx1_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a = new Animal("������",26);
		System.out.println(a);
	}
}
class Animal{
	String name;
	int age;
	
	Animal(String name,int age){
		this.name = name;
		this.age = age;
	}
	
	public String toString() {
		return "name : " + name + ", age : " + age;
	}
}

package chap02;

public class Hello {

	public static void main(String[] args) {
		/* chap02_1
		byte b1 = -22;
		byte b2;
		
		b2 = -128; // -128~127(byteũ��)
		b1 = 127;
		short s1 = -220;
		int i1 =100;
		long l1 = 1000;
		
		System.out.println("b1=" + b1);
		System.out.println("s1=" + s1);
		System.out.println("i1=" + i1);
		System.out.println("l1=" + l1);
		float f1 = 1.0F; // 1.0(x)(�Ǽ��� �⺻�ڷ����� double / float < double / F�� ����ȯ) / 1.0F == 1(float == int)
		double d1 = 1d; // 1.0 == 1d == 1 /double�� �������(int < double)
		System.out.println("f1=" + f1);
		System.out.println("d1=" + d1);
		*/
		
		/* chap02_2
		int a = 10;
		
		String s = "a";
		
		byte b1 = 100;
		int i1 = b1;
		byte b2 = (byte)i1;
		System.out.println("b1="+b1+", i1="+i1);
		
		byte b3= (byte)256;
		System.out.println("b3="+b3);
		
		long l1 = 10;
		float f1 = l1;
		long l2 = (long)f1;
		
		char c1 = 'A';
		short s1 = (short)c1; //A == 65
		char c2 = (char)b1; //100 == d
		
		int i2 = (int)(i1+l1);
		
		System.out.println("��ȣ:" + 1 + 2 + 3);
		System.out.println(1 + 2 + 3 + "��");
		char c3 = 'A';
		int i3 = c3;
		System.out.println("c3=" + c3 + ", i3=" + (char)i3);
		
		int b4; byte b5=1; byte b6=2; b4=b5+b6;
		*/
		
		/* chap02_3
		char single = '\''; // '
		String quote = "Hello \"ȫ�浿!\""; // " "
		String root = "c:\\"; // c:\
		System.out.println(single); 
		System.out.println(quote);
		System.out.println(root);
		System.out.println("����\t�뱸\t�λ�"); //tab
		System.out.println("�ȳ��ϼ���\n�̺κ��� �����ٿ�"); //�ٹٲ�
		System.out.println("\uD64D\uAE38\uB3D9"); //�ѱ� 2����Ʈ�� ��Ÿ��
		*/
		
	}

}

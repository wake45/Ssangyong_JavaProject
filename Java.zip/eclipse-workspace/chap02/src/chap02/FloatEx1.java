package chap02;

public class FloatEx1 {
	public static void main(String[] args) {
		float f = 9.12345678901234567890f;
		float f2 = 1.2345678901234567890f;
		double d = 0.12345678901234567890d;
		
		System.out.printf("	123456789012345678901234%n");
		System.out.printf("1f : %f%n", f);
		System.out.printf("2f : %24.20f%n", f);
		System.out.printf("3f2 : %24.20f%n", f2);
		System.out.printf("4d : %24.20f%n",d);
		
	}
}

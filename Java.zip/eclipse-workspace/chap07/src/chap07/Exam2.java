package chap07;

public class Exam2{
	public static void main(String args[]) {
		Buyer b = new Buyer();
		Tv tv = new Tv();
		Computer com = new Computer();
		SmarttPhone sp = new SmarttPhone();
		b.buy(tv);
		b.buy(com);
		b.buy(sp);
		System.out.println("������ �ܾ� : " + b.money);
		System.out.println("������ ��������Ʈ : " + b.point);
		System.out.println("������ǰ����");
		b.summary();
	}
}

class Product {
	int price;
	int point;
		
	Product(int price){
		this.price = price;
		this.point = (int)(price*0.1);
	}

	@Override
	public String toString() {
		return "Product [price=" + price + ", point=" + point + "]";
	}
}

class Tv extends Product{
	Tv(){
		super(100);
	}

	@Override
	public String toString() {
		return "Tv [prcie=" + price + "]";
	}
}

class Computer extends Product{
	Computer(){
		super(200);
	}

	@Override
	public String toString() {
		return "Computer [price=" + price + "]";
	}
}

class SmarttPhone extends Product{
	SmarttPhone(){
		super(150);
	}

	@Override
	public String toString() {
		return "SmartPhone [price=" + price + "]";
	}
}
class Buyer{
	int money = 500;
	int point = 0;
	
	private Product[] cart = new Product[3];
	int cnt = 0;
	public void buy(Product p) {
		this.money -= p.price;
		this.point += p.point;
		p.toString();
		cart[cnt++] = p;
	}
	public void summary() {
		for(int i = 0 ; i < cart.length ; i++) {
			System.out.println(cart[i].toString());
		}
		System.out.println("��ü���� : " + (500-money));
	}
}
package chap07;

class FinalValue{
	final int NUM;
	FinalValue(int num){
		NUM = num;
		//NUM=200;
	}
	FinalValue(){
		this(100);
	}
	public int getNum() {
		return NUM;
	}
}

public class FinalMethodEx1{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FinalValue f1 = new FinalValue();
		System.out.println(f1.getNum());
		FinalValue f2 = new FinalValue(120);
		System.out.println(f2.getNum());
	}
}

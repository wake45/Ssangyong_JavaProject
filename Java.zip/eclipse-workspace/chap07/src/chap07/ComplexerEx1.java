package chap07;

public class ComplexerEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Complexer com = new Complexer();
		System.out.println("�⺻ ��ũ�� : " + Printerable.INK);
		System.out.println("FAX ��ȣ : " + Complexerable.FAX_NO);
		com.print();
		com.scan();
		com.receive("02-5678");
		com.send("02-5678");
		if(com instanceof Complexer) {
			System.out.println("com ���������� ��ü�� Complexer ��ü��");
		}
		if(com instanceof Complexerable) {
			System.out.println("com ���������� ��ü�� Complexerable ��ü��");
		}
		Complexerable ca = com;
		ca.print();
		ca.scan();
		ca.receive("02-1234");
		ca.send("02-1234");
		if(com instanceof Printerable) {
			Printerable pa = com;
			pa.print();
			System.out.println(pa.INK);
		}
		if(com instanceof Scannerable) {
			Scannerable sa = com;
			sa.scan();
		}
		if(com instanceof Faxable) {
			Faxable fa = com;
			fa.receive(fa.FAX_NO);
			fa.send("02-3456");
			fa.receive("02-3456");
		}
	}

}

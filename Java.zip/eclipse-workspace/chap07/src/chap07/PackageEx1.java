package chap07;

import chap_07.Pack2;
import java.util.Date;

class Pack1{
	void method() {
		System.out.println("chap07.Pack1.method() ȣ���");
	}
}

public class PackageEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pack1 p1 = new Pack1();
		p1.method();
		Pack2 p2 = new Pack2();
		p2.method();
		Date d = new Date();
	}

}

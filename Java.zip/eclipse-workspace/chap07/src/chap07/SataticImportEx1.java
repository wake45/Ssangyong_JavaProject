package chap07;

import static java.lang.Math.*;
import static java.lang.System.out;

public class SataticImportEx1 {
	public static void main(String args[]) {
		out.println(random());
		
		out.println("Math.PI : " + PI);
	}
}

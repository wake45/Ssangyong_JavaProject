package chap07;

class Food{ // �ֻ��� �θ�
	int price;
	int point;
	
	Food(int price){
		this.price = price;
		this.point = (int)(price*0.1);
	}
}

class Fruit extends Food{ //�θ�Ŭ����
	double brix;
		
	Fruit(int price, double brix2){
		super(price);
		this.brix = brix2;
	}
}
class Drink extends Food{
	int ml;
	Drink(int price , int ml){
		super(price);
		this.ml = ml;
	}
}
class Snack extends Food{
	int gram;
	Snack(int price, int gram){
		super(price);
		this.gram = gram;
	}
}

class Apple extends Fruit{
	Apple(int price , double brix){
		super(price,brix);
	}

	@Override
	public String toString() {
		return "Apple ";
	}
}
class Peach extends Fruit{
	Peach(int price, double brix){
		super(price,brix);
	}

	@Override
	public String toString() {
		return "Peach ";
	}
}
class Coke extends Drink{
	Coke(int price , int ml){
		super(price,ml);
	}

	@Override
	public String toString() {
		return "Coke ";
	}
}
class Sidar extends Drink{
	Sidar(int price,int ml){
		super(price,ml);
	}

	@Override
	public String toString() {
		return "Sidar ";
	}
}
class Biscuit extends Snack{
	Biscuit(int price, int gram){
		super(price,gram);
	}

	@Override
	public String toString() {
		return "Biscuit ";
	}
}
class Cookie extends Snack{
	Cookie(int price, int gram){
		super(price, gram);
	}

	@Override
	public String toString() {
		return "Cookie ";
	}
}

class Buyer2{
	int money = 10000;
	int point = 0;
	Food Cart[] = new Food[20];
	int cnt = 0;
	
	void buy(Food f) {
		if(f.price> money) {
			System.out.println("�ܾ׺���");
			return;
		}else {
			this.money -= f.price;
			this.point += f.point;
			System.out.println(f.toString());
			Cart[cnt++] = f;
		}
	}
	void summary(){
		int cnt_fruit = 0;
		int cnt_drink = 0;
		int cnt_snack = 0;
		int pri_fruit = 0;
		int pri_drink = 0;
		int pri_snack = 0;
		String val_fruit = "";
		String val_drink = "";
		String val_snack = "";
		for(int i = 0 ; i < cnt ; i++) {
			System.out.println(Cart[i].toString());
			System.out.println("���� : " + Cart[i].price + " ���� ����Ʈ : " + Cart[i].point);
			if(Cart[i] instanceof Fruit) {
				cnt_fruit++;
				pri_fruit += Cart[i].price;
				val_fruit += Cart[i].toString();
			}
			else if(Cart[i] instanceof Drink) {
				cnt_drink++;
				pri_drink += Cart[i].price;
				val_drink += Cart[i].toString();
			}
			else if(Cart[i] instanceof Snack) {
				cnt_snack++;
				pri_snack += Cart[i].price;
				val_snack += Cart[i].toString();
			}
		}
		System.out.println( "   �� ���� ���� : " + cnt_fruit + 
				   			" �� ���� ���� : " + pri_fruit + 
				   			" �� ���� ��� : " + val_fruit);
		System.out.println( " �� ���� ���� : " + cnt_drink + 
		   		   			" �� ���� ���� : " + pri_drink + 
		   		   			" �� ���� ��� : " + val_drink);
		System.out.println(	" �� ���� ���� : " + cnt_snack + 
		   		   			" �� ���� ���� : " + pri_snack + 
		   		   			" �� ���� ��� : " + val_snack);
	}
}

public class Exam4 {
	public static void main(String args[]) {
		Apple apple = new Apple(1000,10.5);
		System.out.println("��� ���� : " + apple.price);
		System.out.println("��� �絵 : " + apple.brix);
		Peach peach = new Peach(1000,13.5);
		Coke coke = new Coke(500,500);
		Sidar sidar = new Sidar(1500,1500);
		Biscuit bis = new Biscuit(10000,500);
		Cookie cookie = new Cookie(500,5000);
		Buyer2 b = new Buyer2();
		b.buy(apple);
		b.buy(peach);
		b.buy(coke);
		b.buy(sidar);
		b.buy(bis);
		b.buy(cookie);
		System.out.println("���� �ܾ� : " + b.money);
		System.out.println("���� ����Ʈ : " + b.point);
		b.summary();
	}
}

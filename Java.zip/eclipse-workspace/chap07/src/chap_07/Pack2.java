package chap_07;

public class Pack2{
	public void method() {
		System.out.println("chap_07.Pack2.method() ȣ���");
	}
}

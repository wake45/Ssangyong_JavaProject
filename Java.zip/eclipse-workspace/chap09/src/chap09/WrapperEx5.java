package chap09;

public class WrapperEx5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer data = 1;
		switch(data) {
			case 1 : System.out.println("����");break;
			case 2 : System.out.println("����");break;
		}
	}

}

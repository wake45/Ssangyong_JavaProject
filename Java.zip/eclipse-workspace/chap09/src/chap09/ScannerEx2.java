package chap09;

import java.util.Scanner;

public class ScannerEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int sum = 0;
		int cnt = 0;
		while(sc.hasNextInt()) {
			sum += sc.nextInt();
			cnt++;
		}
	}

}

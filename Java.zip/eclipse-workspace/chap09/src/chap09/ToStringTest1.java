package chap09;

class Animal{
	String name;
	int age;
	public Animal(String name, int age) {
		this.age= age;
		this.name = name;
	}
	public String toString() {
		return this.getClass().getName() + "@" + System.identityHashCode(this);
	}
}
public class ToStringTest1 {
	public static void main(String args[]) {
		Animal a1 = new Animal("ȣ����", 20);
		System.out.println(a1);
	}
}

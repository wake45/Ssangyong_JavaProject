package chap09;

public class StringEx4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "ABC";
		String str1 = "ABC1";
		System.out.println("main : " + str);
		str = change(str);
		System.out.println("change ���� main : " + str);
		change(str);
		System.out.println("change ���� main-�缳�� ���� : " + str);
	}
	static String change(String str) {
		str += "456";
		System.out.println("change() s:" + str);
		return str;
	}
}

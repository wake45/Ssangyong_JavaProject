package chap09;

class Value{
	String value;
	public Value(String value) {
		this.value = value;
	}
	public int hashCode(){
		return value.hashCode();
	}
}
public class HashCodeEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str1 = new String("abc");
		String str2 = new String("abc");
		String str3 = "abc";

		System.out.println(str1 == "abc");
		System.out.println(str1.equals(str2));
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());

		System.out.println(System.identityHashCode(str1));
		System.out.println(System.identityHashCode(str2));
		System.out.println("=========================================");

		Value var1 = new Value("abc");
		Value var2 = new Value("abc");

		System.out.println(var1.value == var2.value); // false
		System.out.println(var1.equals(var2)); // false
		System.out.println(var1.hashCode());
		System.out.println(var2.hashCode());
		System.out.println(System.identityHashCode(var1));
		System.out.println(System.identityHashCode(var2));
	}

}

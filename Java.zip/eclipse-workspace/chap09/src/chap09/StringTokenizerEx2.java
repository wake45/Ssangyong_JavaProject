package chap09;

import java.util.StringTokenizer;

public class StringTokenizerEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String source = "x=100*(200+300)/2";
		StringTokenizer st = new StringTokenizer(source,"+-*/=()",true);
		
		while(st.hasMoreTokens()) {
			System.out.println(st.nextToken());
		}
	}

}

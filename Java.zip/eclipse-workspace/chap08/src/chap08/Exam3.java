package chap08;

class MyException2 extends Exception{
	
}
class MyException3 extends MyException2{

}
public class Exam3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			throw new Exception();
		}catch(MyException3 e) {
			System.out.println("Exception3");
		}catch(MyException2 e) {
			System.out.println("Exception2");
		}catch(Exception e) {
			System.out.println("Exception");
		}
	}

}

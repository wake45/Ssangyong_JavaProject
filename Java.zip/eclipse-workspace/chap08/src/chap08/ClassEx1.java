package chap08;



public class ClassEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sample s = new Sample();
		s.num = 99;
		System.out.println(s);
		try {
			Class<?> c = Class.forName("ClassEx1.Sample");
			
			Sample e = (Sample)c.newInstance();
			e.num = 10;
			System.out.println(e);
		}catch(ClassNotFoundException e) {
			System.out.println("fdfd1");
			e.printStackTrace();
		}catch(InstantiationException e1) {
			System.out.println("fdfd2");
			e1.printStackTrace();
		}catch(IllegalAccessException e1) {
			System.out.println("fdfd3");
			e1.printStackTrace();
		}
	}
}

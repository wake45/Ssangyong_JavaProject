package chap08;

import java.io.IOException;

class Child extends Parent{
	void method(int i) throws IOException{
		System.out.println("child" + i);
		try {
			throw new IOException();
		}catch(IOException e) {
			System.out.println("������");
		}
	}
}

class Parent{
	void method(int i) throws Exception{
		System.out.println("parent" + i);
	}
}

public class ExceptionEx8 {
	
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Child ch = new Child();
		Parent p = new Parent();
		Parent cp = new Child();
		ch.method(1);
		p.method(1);
		cp.method(1);
	}

}

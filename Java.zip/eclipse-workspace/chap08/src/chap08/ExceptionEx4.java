package chap08;

public class ExceptionEx4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			first();
		}catch(Exception e) {
			//e.printStackTrace(); //�����޼����� �ܰ躰�� ���
			//e.getMessage();
			//e.toString();
		}
	}
	
	private static void first() throws Exception{
		System.out.println("first method");
		second();
	}
	private static void second() throws Exception{
		System.out.println("second method");
		System.out.println(Integer.parseInt("abc"));
	}
}

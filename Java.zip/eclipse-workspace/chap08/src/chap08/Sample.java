package chap08;

public class Sample{
	int num;
	
	public String toString() {
		return num + " ";
	}
}
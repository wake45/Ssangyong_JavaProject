package chap08;

class AutoCloseableUse implements AutoCloseable{
	public void close() {
		System.out.println("close �P��");
	}
}

public class AutoCloseableEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try(AutoCloseableUse cr = new AutoCloseableUse()){
			System.out.println("process");
			System.out.println();
		}
	}

}

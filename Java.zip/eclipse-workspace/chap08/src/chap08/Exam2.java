package chap08;

class UnsupprtFunctionException extends RuntimeException{
	private final int ERR_CODE;
	
	UnsupprtFunctionException(String msg, int ERR_CODE){
		super(msg);
		this.ERR_CODE = ERR_CODE;
	}
	
	public int getErrCode() {
		return ERR_CODE;
	}
	public String getMessage(){
		return super.getMessage();
	}
}

public class Exam2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			throw new UnsupprtFunctionException("�������� �ʴ� ����Դϴ�.",200);
		}catch(UnsupprtFunctionException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getErrCode());
		}
	}

}

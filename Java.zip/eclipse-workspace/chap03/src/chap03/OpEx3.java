package chap03;

public class OpEx3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(10%8);
		System.out.println(-10%8);
		System.out.println(10%-8);
		System.out.println(-10%-8);
		
		System.out.println(10/8);
		System.out.println(-10/8);
		System.out.println(10/-8);
		System.out.println(-10/-8);
	}

}

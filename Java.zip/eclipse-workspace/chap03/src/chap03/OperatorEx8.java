package chap03;

public class OperatorEx8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 1000000;
		int b = 2000000;
		
		long c = a*b;
		
		System.out.println(c);

	}

}

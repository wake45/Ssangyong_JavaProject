package chap03;

import java.util.Scanner;

public class Exam6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner sc = new Scanner(System.in);
			System.out.print("��� ���� �Է� : ");
			int num = sc.nextInt();
			
			System.out.println((num%10)>0 ? (num/10)+1 : (num/10));
			
	}

}

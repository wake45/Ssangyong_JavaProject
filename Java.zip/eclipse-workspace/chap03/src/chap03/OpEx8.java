package chap03;

public class OpEx8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("8 << 2 : " + (8 << 2));
		System.out.println("8 >> 2 : " + (8 >> 2));
		System.out.println("8 >>> 2 : " + (8 >>> 2));
		System.out.println("-8 << 2 : " + (-8 << 2));
		System.out.println("-8 >> 2 : " + (-8 >> 2));
		System.out.println("-8 >>> 2 : " + (-8 >>> 2)); //111111100
		System.out.println(Integer.toBinaryString((-8 >>> 2)));
	}

}


package chap03;

public class OpEx7 {
	public static void main(String[] args) {
		System.out.println("6&3="+(6&3));
		
		System.out.println("6|3="+(6|3));
		
		System.out.println("6^3="+(6^3)); //xor
		
		System.out.println("~10="+ ~10); //not
	}
}

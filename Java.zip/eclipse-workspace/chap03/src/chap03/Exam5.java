package chap03;

import java.util.Scanner;

public class Exam5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.print("���� �Է� : ");
		String str = sc.next();
		
		System.out.println(str.charAt(0) > 'a' && str.charAt(0) < 'z' ? (char)(str.charAt(0)-32) : "�ҹ��ڰ� �ƴմϴ�");
		
		//System.out.println(str.toUpperCase().charAt(0));
	}

}

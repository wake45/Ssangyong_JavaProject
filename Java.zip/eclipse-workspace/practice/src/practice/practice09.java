package practice;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class practice09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 9-1)
		/*
		SutdaCard c1 = new SutdaCard(3,true);
		SutdaCard c2 = new SutdaCard(3,true);
		System.out.println("c1="+c1); 
		System.out.println("c2="+c2); 
		System.out.println("c1.equals(c2):"+c1.equals(c2)); }
		*/
		
		// 9-2)
		/*
		Point3D p1 = new Point3D(1,2,3);
		Point3D p2 = new Point3D(1,2,3);
		System.out.println(p1); System.out.println(p2);
		System.out.println("p1==p2?"+(p1==p2));
		System.out.println("p1.equals(p2)?"+(p1.equals(p2)));
		*/
		
		// 9-3)
		/*
		String fullPath = "c:\\jdk1.8\\work\\PathSeparateTest.java";
		String path = "";
		String fileName = "";
	
		String []a  = fullPath.split("\\\\");
		for(int i = 0 ; i < a.length-1 ; i++) {
			path += a[i] + "\\\\";
		}
		fileName = a[a.length-1];
		
		System.out.println("fullPath:"+fullPath);
		System.out.println("path:"+path);
		System.out.println("fileName:"+fileName);
		*/
		
		// 9-4)
		//printGraph(new int[] {3,7,1,4},'*');
	
		// 9-5)
		//System.out.println(count("12345AB12AB345AB","AB"));
		//System.out.println(count("12345","AB"));
		
		// 9-6)
		//String src = "12345";
		//System.out.println(fillZero(src,10));
		//System.out.println(fillZero(src,-1));
		//System.out.println(fillZero(src,3));

		// 9-7)
		//System.out.println(contains("12345","23"));
		//System.out.println(contains("12345","67"));

		// 9-8)
		//System.out.println(round(3.1415,1));
		//System.out.println(round(3.1415,2));
		//System.out.println(round(3.1415,3));
		//System.out.println(round(3.1415,4));
		//System.out.println(round(3.1415,5));
		
		// 9-9)
		//System.out.println("(1!2@3^4~5)"+" -> " + delChar("(1!2@3^4~5)","~!@#$%^&*()"));
		//System.out.println("(1 2 3 4\t5)"+" -> " + delChar("(1 2 3 4\t5)"," \t"));

		// 9-10)
		//String str = "������";
		//System.out.println(format(str,7,0)); 
		//System.out.println(format(str,7,1)); 
		//System.out.println(format(str,7,2));
		
		// 9-11)
		/*
		Scanner sc = new Scanner(System.in);
		if(args.length != 2) {
			System.out.println("���� �Է��Ͻÿ�");
			return;
		}
		
		System.out.println("���� �ܰ� ����, �ΰ��� ������ �Է����ּ���. (2~9) ���� : ");
		int a = Integer.parseInt(args[0]); 
		int b = Integer.parseInt(args[1]);
		while(true) {
			if(a <= b) {
				for(int i = 1 ; i <= 9 ; i++ ) {
					System.out.println(a + "*" + i + "=" + a*i);
				}
				System.out.println();
				a++;
			}
			else {
				break;
			}
		}
		*/
		
		// 9-12)
		/*
		for(int i=0; i< 20; i++)
			System.out.print(getRand(1,-3)+",");
		}
		*/
		
		// 9-13)
		//String src = "aabbccAABBCCaa";
		//System.out.println(src);
		//System.out.println("aa " + stringCount(src, "aa") +"�� �� ã�ҽ��ϴ� .");
	
		// 9-14)
		/*
		String[] phoneNumArr = { "012-3456-7890", "099-2456-7980", "088-2346-9870", "013-3456-7890" };
		ArrayList list = new ArrayList(); 
		Scanner s = new Scanner(System.in);
		
		while(true){
			System.out.print(">>"); 
			String input=s.nextLine().trim();
			
			if(input.equals("")){
				continue; 
			}else if (input.equalsIgnoreCase("Q")){
				System.out.println("����");
				System.exit(0); 
			} 
		
			Pattern p = Pattern.compile(".*"+input+".*");
			Matcher m[] = new Matcher[phoneNumArr.length];
			for(int i = 0 ; i <phoneNumArr.length ; i++) {
				String tmp = phoneNumArr[i].replace("-", "");
				
				
				m[i] = p.matcher(tmp);
			}
			
			for(int i = 0 ; i <phoneNumArr.length ; i++) {
				while(m[i].find()) {
					list.add(phoneNumArr[i]);
					break;
				}
			}
			

			if(list.size()>0){
				System.out.println(list);
				list.clear();
			}else{
				System.out.println("��ġ�ϴ� ��ȣ�� �����ϴ� ."); 
			} 
		} 
		*/
	}
	// 9-4)
	/*
	static void printGraph(int[] dataArr, char ch) {
		for(int i = 0 ; i < dataArr.length ; i++) {
			for(int j = 0 ; j < dataArr[i]; j++) {
				System.out.print(ch);
			}
			System.out.println(dataArr[i]);
		}
	}
	*/
	
	// 9-5)
	/*
	public static int count(String src, String target) {

		int count = 0;
		int pos = 0;
		
		while(true) {
			if(src.indexOf(target,pos+1) != -1) {
				count++;
				pos = src.indexOf(target,pos+1);
			}else {
				return count;
			}
		}
	}
	*/
	
	// 9-6)
	/*
	public static String fillZero(String src,int length) {
		
		String tmp = "";
		if(length <= 0) {
			return "";
		}
		if(src == null) {
			return src;
		}
		
		if(src.length() == length) {
			return src;
		} 
		else if(src.length() > length) {
			for(int i = 0 ; i < length ; i++) {
				tmp += src.charAt(i);
			}
			return tmp;
		}
		else if(src.length() < length) {
			for(int i = 0 ; i < length-src.length() ; i++) {
				tmp += "0";
			}
			tmp += src;
			return tmp;
		}
		return src;
	}
	*/
	
	
	// 9-7)
	/*
	public static boolean contains(String src,String target) {
		return (src.indexOf(target) == -1?false:true);
	}
	*/
	
	// 9-8)
	/*
	public static double round(double d, int n) {
		double result = d*(Math.pow(10,n));
		result = Math.round(result);
		result *= Math.pow(10,-n);
		
	}
	*/
	
	// 9-9)
	/*
	public static String delChar(String src, String delCh) {
		
		StringBuffer sb = new StringBuffer(src);
		for(int i = 0 ; i < src.length() ; i++) {
			for(int j = 0 ; j < delCh.length() ; j++) {
				if(src.charAt(i) == delCh.charAt(j)) {
					sb.replace(i, i+1, " ");
				}
			}
		}
		src = sb.toString();
		return src.replaceAll(" ","");
	}
	*/
	
	// 9-10)
	/*
	public static String format(String str,int length,int alignment) {
		//��0 ��1 ��2
		String tmp = "";
		if(length < str.length()) {
			for(int i = 0 ; i < length ; i++) {
				tmp += str.charAt(i);
			}
			return tmp;
		}
		else {
			char ch[] = new char[length];
			char src[] = new char[str.length()];
			String result = "";
			for(int i = 0 ; i < ch.length ; i++) {
				ch[i] = ' ';
			}
			for(int i = 0 ; i < src.length ; i++) {
				src[i] = str.charAt(i);
			}
			
			if(alignment == 0) {
				System.arraycopy(src, 0,ch,0, str.length());
				for(int i = 0 ; i < ch.length ; i++) {
					result += ch[i];
				}
			}else if(alignment == 1) {
				System.arraycopy(src, 0,ch,(ch.length/2)-(str.length()-2), str.length());
				for(int i = 0 ; i < ch.length ; i++) {
					result += ch[i];
				}
			}else if(alignment == 2) {
				System.arraycopy(src, 0,ch,ch.length-str.length(), str.length());
				for(int i = 0 ; i < ch.length ; i++) {
					result += ch[i];
				}
			}
			return result;
		}
	}
	*/
	
	// 9-12)
	/*
	public static int getRand(int from,int to) {
		int tmp = 0;
		if(from <= to) {
			tmp = (int)(Math.random()*(to+1-from))+from;
			// 2 ~ 7  7-> 0~7
		}else if(from > to) {
			tmp =(int)(Math.random()*(from+1-to))+to;
		}
		return tmp;
	}
	*/
	
	// 9-13)
	/*
	static int stringCount(String src, String key) {
		return stringCount(src,key,0);
	}
	static int stringCount(String src, String key, int pos) {
		int count = 0;
		int index = 0;
		if (key == null || key.length() == 0)
			return 0; 
		
		while(true) {
			if( src.indexOf(key,index) != -1) {
				index = src.indexOf(key,index) + (key.length()-1);
				count++;
			}
			if(index+key.length() >= src.length()) {
				break;
			}
		}
		
		return count; 
	}
	*/
}

// 9-1)
/*
class SutdaCard {
	int num; boolean isKwang;
	SutdaCard() {
		this(1, true); 
	} 
	SutdaCard(int num, boolean isKwang) {
		this.num = num;
		this.isKwang = isKwang; 
	} 
	public boolean equals(Object obj) {
		if(obj == null) {
			return false;
		}
		if(obj == this) {
			return true;
		}
		SutdaCard o = (SutdaCard)obj;
		if(o.num != this.num) {
			return false;
		}
		if(o.isKwang != this.isKwang) {
			return false;
		}
		return true;
	}
	public String toString() {
		return num + ( isKwang ? "K":""); 
	}
}
*/

//9-2)
/*
class Point3D {
	int x,y,z;
	Point3D(int x, int y, int z) {
		this.x=x;
		this.y=y;
		this.z=z; 
	} 
	Point3D() {
		this(0,0,0); 
	} 
	public boolean equals(Object obj) {
		if(obj == null) {
			return false;
		}
		if(obj == this) {
			return true;
		}
		Point3D o = (Point3D)obj;
		if(o.x != this.x) {
			return false;
		}
		if(o.y != this.y) {
			return false;
		}
		if(o.z != this.z) {
			return false;
		}
		return true;	
	}
	public String toString() {
		return "[ x = " + x + ", y = " + y + ", z = " + z + "]";
	}
}
*/
package practice;

import java.util.ArrayList;
import java.util.Scanner;

public class practice11 {
	// 11-14)
	//static ArrayList record = new ArrayList();
	//static Scanner s = new Scanner(System.in);
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		// 11-1)
		/*
		ArrayList list1 = new ArrayList();
		ArrayList list2 = new ArrayList();
		ArrayList kyo = new ArrayList(); 
		ArrayList cha = new ArrayList();
		ArrayList hap = new ArrayList();
			
		list1.add(1);
		list1.add(2);
		list1.add(3);
		list1.add(4);
			
		list2.add(3);
		list2.add(4);
		list2.add(5);
		list2.add(6);
						
		kyo.addAll(list1);
		kyo.retainAll(list2);
			
		cha.addAll(list1);
		cha.removeAll(list2);
			
		hap.addAll(list1);
		hap.removeAll(list2);
		hap.addAll(list2);
			
		System.out.println("list1="+list1);
		System.out.println("list2="+list2);
		System.out.println("kyo="+kyo);
		System.out.println("cha="+cha);
		System.out.println("hap="+hap);	
		*/
		
		// 11-2)
		/*
		ArrayList list = new ArrayList();
		list.add(3);
		list.add(6);
		list.add(2);
		list.add(2);
		list.add(2);
		list.add(7);
		HashSet set = new HashSet(list); //�ߺ�����
		TreeSet tset = new TreeSet(set); //�������� ����
		Stack stack = new Stack(); //���Լ���
		stack.addAll(tset); //��� �߰�
		
		while(!stack.empty()) //���� ���� �������� ���
			System.out.println(stack.pop());
		// 7 6 3 2
		*/
		 
		// 11-3) d -> a
		// 11-4) 11��° -> 6��°(�����̹Ƿ� ���� ����� �����ɸ�)
		// 11-5)
		/*
		ArrayList list = new ArrayList();
		list.add(new Student("ȫ�浿",1,1,100,100,100));
		list.add(new Student("���ü�",1,2,90,70,80));
		list.add(new Student("���ڹ�",1,3,80,80,90));
		list.add(new Student("���ڹ� ",1,4,70,90,70)); 
		list.add(new Student("���ڹ�",1,5,60,100,80));
		
		Collections.sort(list);	
		Iterator it=list.iterator();
		
		while(it.hasNext())
			System.out.println(it.next()); 
		*/   
		// 11-6)
		/*
		TreeSet set = new TreeSet(new Comparator() {
			public int compare(Object o1,Object o2) {
				 if(o1 instanceof Student && o2 instanceof Student) {
					 Student s1 = (Student)o1;
					 Student s2 = (Student)o2;
					 return (int)(s1.getAverage() - s2.getAverage());
				 }
				 
				 return -1;
			}
		});
		set.add(new Student("ȫ�浿",1,1,100,100,100));
		set.add(new Student("���ü�",1,2,90,70,80));
		set.add(new Student("���ڹ�",1,3,80,80,90));
		set.add(new Student("���ڹ�",1,4,70,90,70));
		set.add(new Student("���ڹ�",1,5,60,100,80));
		
		Iterator it = set.descendingIterator();
		
		while(it.hasNext())
			System.out.println(it.next());
		System.out.println("[60~69]:"+getGroupCount(set,60,70));
		System.out.println("[70~79]:"+getGroupCount(set,70,80));
		System.out.println("[80~89]:"+getGroupCount(set,80,90));
		System.out.println("[90~100]:"+getGroupCount(set,90,101));
		*/
		// 11-7)
		/*
		ArrayList list = new ArrayList();
		list.add(new Student("���ڹ�",2,1,70,90,70));
		list.add(new Student("���ڹ�",2,2,60,100,80)); 
		list.add(new Student("ȫ�浿",1,3,100,100,100));
		list.add(new Student("���ü�",1,1,90,70,80)); 
		list.add(new Student("���ڹ�",1,2,80,80,90)); 
		
		Collections.sort(list,new BanNoAscending());
		
		Iterator it=list.iterator();
		while(it.hasNext())
			System.out.println(it.next());
		*/
		// 11-8)
		/*
		ArrayList list = new ArrayList();
		list.add(new Student("���ڹ�",2,1,70,90,70));
		list.add(new Student("���ڹ�",2,2,60,100,80));
		list.add(new Student("ȫ�浿",1,3,100,100,100));
		list.add(new Student("���ü�",1,1,90,70,80));
		list.add(new Student("���ڹ�",1,2,80,80,90));
		calculateSchoolRank(list); 
		Iterator it=list.iterator();
		while(it.hasNext())
			System.out.println(it.next());
		*/
		// 11-9)
		/*
		ArrayList list = new ArrayList();
		list.add(new Student("���ڹ�",2,1,70,90,70));
		list.add(new Student("���ڹ�",2,2,60,100,80));
		list.add(new Student("ȫ�浿",1,3,100,100,100));
		list.add(new Student("���ü�",1,1,90,70,80));
		list.add(new Student("���ڹ�",1,2,80,80,90));
	
		calculateSchoolRank(list); 
		calculateClassRank(list);
		Iterator it=list.iterator(); 
		while(it.hasNext()) 
			System.out.println(it.next());
		*/
		// 11-10)
		
		/*�ؽ� ���� �ؽ����� Ȱ���Ͽ� ������ �Ѵ�. �ؽ� �˰������� Ư���� ������ ��ġ�� �����ȴ�.
		 * �׷��Ƿ� list�� �ٲ� ���ʿ� �������� �Է��� �Ǳ⶧���� ������ �ǹ̸� �����ν� ���ڸ� �����ش�.
		 * �ߺ����Ÿ� ���� �ߺ����� �ڵ带 �ִ��� ����Ʈ�� ����� Collections.shuffle�� ����� ������
		*/
		/*
		Set set=new HashSet();
		int[][] board=new int[5][5];
		for(int i=0;set.size()<25;i++){
			String str = (int)(Math.random()*30)+1+"";
			//System.out.println(str);
			set.add(str);		
		} 
		List li = new ArrayList(set);
		Collections.shuffle(li);
		Iterator it=li.iterator();
		for(int i=0; i<board.length ;i++){
			for(int j=0;j<board[i].length;j++){
				board[i][j]=Integer.parseInt((String)it.next());
				System.out.print((board[i][j]<10?" ":"") +board[i][j] + " "); 
				} 
			System.out.println(); 
			} 
		}
		*/
		// 11-11)
		/*
		SutdaCard c1 = new SutdaCard(3,true);
		SutdaCard c2 = new SutdaCard(3,true); 
		SutdaCard c3 = new SutdaCard(1,true); 
		HashSet set = new HashSet(); 
		set.add(c1); 
		set.add(c2); 
		set.add(c3); 

		System.out.println(set);
		*/
		// 11-12)
		/*
		SutdaDeck deck = new SutdaDeck();
		deck.shuffle(); 
		Player p1=new Player("Ÿ¥",deck.pick(),deck.pick());
		Player p2=new Player("����",deck.pick(),deck.pick());
		System.out.println(p1+" "+deck.getPoint(p1)); 
		System.out.println(p2+" "+deck.getPoint(p2)); 
		*/
		// 11-13)
		/*
		SutdaDeck deck = new SutdaDeck();
		deck.shuffle(); 
		Player []pArr={
			new Player("Ÿ¥",deck.pick(),deck.pick()),
			new Player("����",deck.pick(),deck.pick()),
			new Player("����",deck.pick(),deck.pick()),
			new Player("�߼�",deck.pick(),deck.pick()),
			new Player("�ϼ�",deck.pick(),deck.pick()) };
			TreeMap rank = new TreeMap( new Comparator(){
			public int compare(Object o1,Object o2){ 
				if(o1 instanceof Player &&
						o2 instanceof Player) {
			
					Player p1 = (Player)o1;
					Player p2 = (Player)o2;
					
					return p2.point - p1.point;
				}
				return -1;
			}}); 
			for(int i=0;i<pArr.length;i++){
				Player p=pArr[i];
				rank.put(p,deck.getPoint(p));
				System.out.println(p+" "+deck.getPoint(p)); 
			} 
			System.out.println();
			System.out.println("1����"+rank.firstKey()+" �Դϴ�.");
		}*/
		// 11-14)
		/*
		 while(true){
		  switch(displayMenu()) {
		  	case 1: 
		  		inputRecord(); 
		  		break;
		  	case 2: 
		  		displayRecord(); 
		  		break;
		  	case 3:
		  		System.out.println("���α׷��� �����մϴ�."); 
		  		System.exit(0);
		  } 
		}
		*/
	}
	/*
	// 11-14)
	static int displayMenu(){
		System.out.println("**************************************************");
		System.out.println("*���� ���� ���α׷� *"); 
		System.out.println("**************************************************"); 
		System.out.println(); 
		System.out.println("1.�л����� �Է��ϱ�");
		System.out.println();
		System.out.println("2.�л����� ����");
		System.out.println(); 
		System.out.println("3.���α׷� ����");
		System.out.println(); 
		System.out.print("���ϴ� �޴��� �����ϼ���.(1~3):");
		int menu=0; 
		
		while(true) {
			menu = s.nextInt();
			if(menu != 1 && menu != 3 && menu!=2) {
				System.out.println("�ٽ��Է��ϼ���");
			}else {
				break;
			}
		}
		return menu;
	}
	static void inputRecord(){
		System.out.println("1.�л����� �Է��ϱ�"); 
		System.out.println("�̸�,��,��ȣ,�����,�����,���м��� �� ������ ������� �Է��ϼ���."); 
	    System.out.println("�Է��� ��ġ���� q�� �Է��ϼ��� ����ȭ������ ���ư��ϴ�."); 
	    Scanner sc = new Scanner(System.in);
	    while(true){
	    	try {
		    	System.out.print(">>"); 
		    	String str = s.next();
		    	if(str.equals("Q") || str.equals("q")) {
		    		break;
		    	}else {
		    		String st[] = str.split(",");
		    		Student stu = new Student(st[0],Integer.parseInt(st[1]),Integer.parseInt(st[2]),Integer.parseInt(st[3]),Integer.parseInt(st[4]),Integer.parseInt(st[5]));
		    		record.add(stu);
		    	}
	    	}catch(Exception e) {
	    		System.out.println("�Է� �����Դϴ�. ");
	    	}
	    }
	}
	static void displayRecord(){
		int koreanTotal=0;
		int englishTotal=0;
		int mathTotal=0; 
		int total=0;
		int length=record.size();
		if(length>0){
			System.out.println();
			System.out.println("�̸� �� ��ȣ ���� ���� ���� ���� ��� ������� �ݵ�� "); 
			System.out.println("====================================================");
			for(int i=0;i<length;i++){
				Student student=(Student)record.get(i);
				System.out.println(student);
				koreanTotal+=student.kor;
				mathTotal+=student.math;
				englishTotal+=student.eng;
				total+=student.total;
			} 
			System.out.println("===================================================="); 
			System.out.println("���� : "+koreanTotal+" "+englishTotal +" "+mathTotal+" "+total); 
			System.out.println(); 
		}
		else{
			System.out.println("===================================================="); 
			System.out.println("�����Ͱ� �����ϴ�."); 
			System.out.println("===================================================="); 
		} 
	}
	*/
	// 11-9)
	/*
	public static void calculateClassRank(List list){
		Collections.sort(list,new ClassTotalComparator());
		int prevBan=-1;
		int prevRank=-1; 
		int prevTotal=-1; 
		int length=list.size(); 
		int temp = 0;
		for(int i = 0 ; i < length ; i++) {
			Student s = (Student)list.get(i);
			if(prevBan != s.ban) {
				prevRank = -1;
				prevTotal = -1;
				temp = i;
			}
			if(s.total == prevTotal) {
				prevRank = s.classRank;
			}
			else if(s.total != prevTotal) {
				s.classRank = (i-temp)+1;
			}
			prevTotal = s.getTotal();
			prevRank = s.classRank;
			prevBan = s.ban;
		}
	}
	*/
	/*
	public static void calculateSchoolRank(List list){
		Collections.sort(list);
		int prevRank= 0; // ���� �������
		int prevTotal=-1; //���� ����
		int length=list.size();  //list����
		
		for(int  i = 0 ; i < length ; i++) {
			Student s = (Student) list.get(i);
			if(s.getTotal() == prevTotal) {
				s.schoolRank = prevRank;
			}
			else {
				s.schoolRank = i+1;
			}
			prevRank = s.schoolRank;
			prevTotal = s.total;
		}
	}
	*/
	// 11-8)
	/*
	public static void calculateSchoolRank(List list){
		Collections.sort(list);
		int prevRank= 0; // ���� �������
		int prevTotal=-1; //���� ����
		int length=list.size();  //list����
		
		for(int  i = 0 ; i < length ; i++) {
			Student s = (Student) list.get(i);
			if(s.getTotal() == prevTotal) {
				s.schoolRank = prevRank;
			}
			else {
				s.schoolRank = i+1;
			}
			prevRank = s.schoolRank;
			prevTotal = s.total;
		}
	}
	*/
	// 11-6)
	/*
	static int getGroupCount(TreeSet tset,int from, int to) {
		int cnt = 0 ;
		
		Iterator it = tset.iterator();
		
		while(it.hasNext()) {
			Student st = (Student)it.next();
			if(st.getAverage() >= from && st.getAverage() < to) {
				cnt++;
			}
		}
		return cnt++;
		}*/
	}
// 11-14)
	/*
class Student implements Comparable{
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	int total;
	int schoolRank;
	int classRank;
	Student(String name,int ban,int no,int kor,int eng,int math){
		 this.name=name;
		 this.ban =ban;
		 this.no =no;
		 this.kor =kor;
		 this.eng =eng;
		 this.math=math;
		 total=kor+eng+math; 
	} 
	int getTotal(){
		return total; 
	} 
	float getAverage(){
		return(int)((getTotal()/3f)*10+0.5)/10f;
	} 
	public int compareTo(Object o){ 
		if(o instanceof Student){
			Student tmp=(Student)o;
		return tmp.total-this.total; 
		}
		else{
			return-1; 
		} 
	}
	public String toString(){
		return name +","+ban +","+no +","+kor +","+eng +","+math +","+getTotal() +","+getAverage() +","+schoolRank +","+classRank ; 
	} 
}*/
// 11-13)
/*
class SutdaDeck {
	final int CARD_NUM=20;
	SutdaCard[] cards=new SutdaCard[CARD_NUM];
	int pos=0;
	HashMap jokbo= new HashMap();
	SutdaDeck(){
		for(int i=0;i<cards.length;i++){
			int num=i%10+1;
			boolean isKwang=i<10&&(num==1||num==3||num==8);
			cards[i]=new SutdaCard(num,isKwang); 
		}
		registerJokbo(); 
	} 
	void registerJokbo(){
		jokbo.put("KK", 4000);
		jokbo.put("1010",3100);
		jokbo.put("12", 2060);
		jokbo.put("99", 3090);
		jokbo.put("21", 2060);
		jokbo.put("88", 3080);
		jokbo.put("14", 2050);
		jokbo.put("77", 3070);
		jokbo.put("41", 2050);
		jokbo.put("66", 3060);
		jokbo.put("19", 2040);
		jokbo.put("55", 3050);
		jokbo.put("91", 2040);
		jokbo.put("44", 3040);
		jokbo.put("110",2030);
		jokbo.put("33", 3030);
		jokbo.put("101",2030);
		jokbo.put("22", 3020);
		jokbo.put("104",2020);
		jokbo.put("11", 3010);
		jokbo.put("410",2020);
		jokbo.put("46", 2010);
		jokbo.put("64", 2010);
		} 
		int getPoint(Player p){
			if(p==null)
				return 0;
			SutdaCard c1 = p.c1; 
			SutdaCard c2=p.c2; 
			Integer result=0;
			if(c1.isKwang&&c2.isKwang){
				result=(Integer)jokbo.get("KK");
			}else{
				result=(Integer)jokbo.get(""+c1.num+c2.num);
				if(result==null){
					result=new Integer((c1.num+c2.num)%10+1000);
				}
			} p.point=result.intValue();
			return result.intValue();
			}
		SutdaCard pick() throws Exception{
			SutdaCard c=null;
			if(0<=pos&&pos<CARD_NUM){
				c=cards[pos];
				cards[pos++]=null;
			}else{
				throw new Exception("�����ִ� ī�尡 �����ϴ�.");
				}
			return c; 
			}
		void shuffle(){
			for(int x=0;x<CARD_NUM*2;x++){
				int i=(int)(Math.random()*CARD_NUM);
				int j=(int)(Math.random()*CARD_NUM);
				SutdaCard tmp=cards[i]; 
				cards[i]=cards[j]; 
				cards[j]=tmp; 
			} 
		} 
}
// 11-13)
class Player{
	String name; 
	SutdaCard c1;
	SutdaCard c2;
	int point; 
	Player(String name,SutdaCard c1,SutdaCard c2){
		this.name=name; 
		this.c1=c1;
		this.c2=c2; 
	} 
	public String toString(){ 
		return"["+name+"]"+c1.toString()+","+c2.toString();
	} 
}
class SutdaCard{ 
	int num;
	boolean isKwang;
	SutdaCard(){
		this(1,true);
	} 
	SutdaCard(int num,boolean isKwang){
		this.num=num; 
		this.isKwang=isKwang; 
	}
	public String toString(){
		return num+(isKwang?"K":""); 
	} 
}
*/
// 11-12)
/*
class SutdaDeck {
	final int CARD_NUM=20;
	SutdaCard[] cards = new SutdaCard[CARD_NUM]; 
	int pos=0; 
	HashMap jokbo = new HashMap();
	SutdaDeck(){
		for(int i=0;i<cards.length;i++){
			int num=i%10+1;
			boolean isKwang=i<10&&(num==1||num==3||num==8);
			cards[i]=new SutdaCard(num,isKwang);
		}
		registerJokbo(); 
	}
	void registerJokbo() {
		//��ī�带 ���̶�µ� cards index�� �ΰ��� ���ϴ°ǰ�?
		jokbo.put("KK", 4000); 
		jokbo.put("1010",3100); 
		jokbo.put("99", 3090);
		jokbo.put("88", 3080);
		jokbo.put("77", 3070);
		jokbo.put("66", 3060);
		jokbo.put("55", 3050);
		jokbo.put("44", 3040);
		jokbo.put("33", 3030);
		jokbo.put("22", 3020);
		jokbo.put("11", 3010);
		jokbo.put("12", 2060);
		jokbo.put("21", 2060);
		jokbo.put("14", 2050);
		jokbo.put("41", 2050);
		jokbo.put("19", 2040); 
		jokbo.put("91", 2040);
		jokbo.put("110",2030);
		jokbo.put("101",2030);
		jokbo.put("104",2020);
		jokbo.put("410",2020);
		jokbo.put("46", 2010);
		jokbo.put("64", 2010);

	}
	int getPoint(Player p) {
		if(p == null) return 0;
		
		SutdaCard c1 = p.c1;
		SutdaCard c2 = p.c2;
		
		Integer result = 0;
		
		if(c1.isKwang == true && c2.isKwang == true) {
			result = (Integer)jokbo.get("KK");
		}else {
			if(jokbo.get((c1.num+"")+(c2.num+"")) != null) {
				result = (Integer)jokbo.get((c1.num+"")+(c2.num+""));
			}else {
				result = (c1.num + c2.num)%10 +1000;
			}
		}
		p.point = result;
			//������ ��ȸ�ϰ� Ű�� �ִµ� ��޵� ����???
	
		
		return result.intValue();
	}
	SutdaCard pick() throws Exception{
		SutdaCard c= null;
		if(0<=pos&&pos<CARD_NUM){
			c=cards[pos];
			cards[pos++]=null; 
		}else{
			throw new Exception("�����ִ� ī�尡 �����ϴ� ."); 
		} 
		return c;
	}
	void shuffle(){
		for(int x=0;x<CARD_NUM*2;x++){
			int i=(int)(Math.random()*CARD_NUM);
			int j=(int)(Math.random()*CARD_NUM);
			SutdaCard tmp=cards[i];
			cards[i]=cards[j];
			cards[j]=tmp; 
		} 
	} 
}

class Player{
	String name; SutdaCard c1; SutdaCard c2;
	int point;
	Player(String name,SutdaCard c1,SutdaCard c2){
		this.name=name;
		this.c1=c1;
		this.c2=c2; 
	}
	public String toString(){
		return"["+name+"]"+c1.toString()+","+c2.toString();
	} 
}
class SutdaCard{
	int num; 
	boolean isKwang;
	SutdaCard(){ 
		this(1,true);
		} 
	SutdaCard(int num,boolean isKwang){
		this.num=num;
		this.isKwang=isKwang;
	}
	public String toString(){
		return num+(isKwang?"K":"");
	} 
}
*/
// 11-11)
/*
class SutdaCard{
	int num;
	boolean isKwang;
	SutdaCard(){
		this(1,true); 
	} 
	SutdaCard(int num,boolean isKwang){
		this.num=num;
		this.isKwang=isKwang; 
	} 
	public boolean equals(Object obj){
		if(obj instanceof SutdaCard){
			SutdaCard c=(SutdaCard)obj;
			return num == c.num&&isKwang==c.isKwang; 
		}
		else{
			return false; 
		} 
	} 
	public String toString(){
		return num+(isKwang?"K":""); 
	} 
	
	public int hashCode() {
		
		if(isKwang == true) {
			return 1;
		}
		else {
			return 0;
		}
		
		//return num;
		//return toString().hashCode();
	}
} 
*/
// 11-9)
/*
class ClassTotalComparator implements Comparator{ 
	public int compare(Object o1,Object o2){
			if(o1 instanceof Student && o2 instanceof Student) {
				Student s1 = (Student)o1;
				Student s2 = (Student)o2;
				
				return s1.ban - s2.ban;
				//result�� ����ؼ� ban�� 0�̸� ���� ������
				//�׷��� �״��� ���� total-total�� ����
				
			}
			return -1;
	} 
} 
class Student implements Comparable{
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	int total;
	int schoolRank;
	int classRank; 
	Student(String name, int ban,int no,int kor,int eng,int math){
		this.name=name;
		this.ban =ban;
		this.no =no; 
		this.kor =kor;
		this.eng =eng;
		this.math=math;
		total=kor+eng+math;
	} 
	int getTotal(){
		return total;
	} 
	float getAverage(){
		return(int)((getTotal()/3f)*10+0.5)/10f; 
	} 
	public int compareTo(Object o){
		if(o instanceof Student){
			Student tmp=(Student)o;
			return tmp.total-this.total; 
			}else{
				return-1;
			} 
		} 
	public String toString(){
		return name +","+ban +","+no +","+kor +","+eng +","+math
				+","+getTotal() +","+getAverage() +","+schoolRank +","+classRank;
	} 
}
*/
// 11-8)
/*
class Student implements Comparable{
	String name;
	int ban;
	int no;
	int kor; 
	int eng;
	int math; 
	int total; 
	int schoolRank; 
	Student(String name,int ban,int no,int kor,int eng,int math){
		this.name=name;
		this.ban =ban;
		this.no =no; 
		this.kor =kor; 
		this.eng =eng; 
		this.math=math; 
		total=kor+eng+math; 
	} 

	int getTotal(){
		return total; 
	} 
	float getAverage(){
		return(int)((getTotal()/3f)*10+0.5)/10f; 
	} 
	public int compareTo(Object o){
		Student s = (Student)o;
		return s.getTotal() - this.getTotal();
	} 
	public String toString(){
		return name +","+ban +","+no +","+kor +","+eng +","+math +","+getTotal() +","+getAverage() +","+schoolRank;
	}
}
*/
// 11-7)
/*
class BanNoAscending implements Comparator{
	public int compare(Object o1,Object o2){
		if(o1 instanceof Student && o2 instanceof Student) {
			Student s1 = (Student)o1;
			Student s2 = (Student)o2;
			int temp = -1;
			if(s1.ban >= s2.ban) {
				temp = s1.no - s2.no;
			}else {
				temp = (s1.ban - s2.ban) ;
			}
			return temp;
		}
		
		return -1;
	} 
} 
class Student{
	String name;
	int ban;
	int no; 
	int kor;
	int eng;
	int math;
	Student(String name, int ban ,int no ,int kor, int eng , int math){
		this.name=name;
		this.ban =ban;
		this.no =no;
		this.kor =kor;
		this.eng =eng;
		this.math=math;
	} 
	int getTotal(){
		return kor+eng+math;
	} 
	float getAverage(){
		return(int)((getTotal()/3f)*10+0.5)/10f; 
	} 
	public String toString(){
		return name +","+ban +","+no +","+kor +","+eng +","+math +","+getTotal() +","+getAverage() ; 
	}
}
*/
// 11-6)
/*
class Student implements Comparable{
	String name;
	int ban;
	int no;
	int kor;
	int eng;
	int math;
	Student(String name,int ban,int no,int kor,int eng,int math){  
		this.name=name; 
		this.ban =ban;
		this.no =no;
		this.kor =kor; 
		this.eng =eng;
		this.math=math; 
	} 
	int getTotal(){
		return kor+eng+math; 
	} 
	float getAverage(){
		return(int)((getTotal()/3f)*10+0.5)/10f;
	} 
	public String toString(){
		return name +","+ban +","+no +","+kor +","+eng +","+math +","+getTotal() +","+getAverage() ; 
	} 
	public int compareTo(Object o){
		if(o instanceof Student){
			Student tmp=(Student)o;
			return name.compareTo(tmp.name);
		}
		else{
			return-1; 
		} 
	} 
}
*/
// 11-5)
/*
class Student implements Comparable<Student> {
	String name;
	int ban; 
	int no; 
	int kor,eng, math; 
	Student(String name,int ban,int no,int kor,int eng,int math){
		this.name=name;
		this.ban =ban;
		this.no =no;
		this.kor =kor;
		this.eng =eng;
		this.math=math;
	} 
	int getTotal(){
		return kor+eng+math;
	} 
	float getAverage(){
		return(int)((getTotal()/3f)*10+0.5)/10f;
	} 
	public String toString(){
		return name +","+ban +","+no+","+kor +","+eng +","+math +","+ getTotal()+","+ getAverage(); 
	} 
	
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub

		return this.name.compareTo(o.name);
	}
} 
*/

package practice;

public class practice04 {
	public static void main(String[] args) {
		//4-1)
		/* 1. if(x>10 && x<20) sysout("true");
		 * 2. if(ch!=' ' || ch!='\t') sysout("true");
		 * 3. if(ch=='x' && ch=='X') sysout("true");
		 * 4. if(ch >= '1' && ch <= '9') sysout("true);
		 * 5. if((ch >= 'a' && ch <= 'z')||(ch >= 'A' && ch <='Z')) sysout("true");
		 * 6. if((year%400==0) || ((year%4==0) && (year%100!=0))) sysout("true");
		 * 7. if(!powerOn)
		 * 8. if(str == "yes")
		 */
	
		//4-2) 
		/*int sum = 0;
		for(int i = 1 ; i <=20 ; i++) {
			if(i%2!=0 && i%3!=0) {
				sum += i; //1 5 7 11 13 17 19
			}
		}
		System.out.println(sum);
		*/
		
		//4-3)
		/*int sum = 0;
		for(int  i = 1 ; i <= 10 ; i++) {
			System.out.print("(");
			for(int j = 1 ; j <= i ; j++) {
				System.out.print(j);
				sum += j;
				if(i!=j) {
					System.out.print("+");
				}
			}
			System.out.print(") + ");
		}
		System.out.println("\n"+ sum);
		*/
		
		//4-4)
		/*int sum = 0;
		int i = 1;
		while(sum <= 100) {
			if(i%2==0) {
				sum += i*-1;
			}
			else {
				sum += i;
			}
			System.out.println(i);
			i++;
		}		
		System.out.println(sum);
		*/
		
		//4-5)
		/*int i = 0;
		while(i<=10) {
			int j = 0;
			while(j <= i) {
				System.out.print("*");
				j++;
			}
			System.out.println();
			i++;
		}
		*/
		
		//4-6)
		/*
		for(int i = 1 ; i <= 6 ; i++) {
			for(int j = 1 ; j<= 6 ; j++) {
				if(i+j==6) {
					System.out.println("(" + i + "," + j + ")");
				}
			}
		}
		*/
		
		//4-7)
		/*int value = (int)((Math.random())*6)+1; 
		System.out.println("value:"+value);
		*/
		
		//4-8)
		/*
		for(int i=0;i<=10;i++) {
			for(int j=0;j<=10;j++) {
				if((2*i+4*j) == 10) {
					System.out.println("x=" + i + ", y=" + j );
				}
			}
		}
		*/
		
		//4-9)
		/*
		String str = "12345"; 
		int sum = 0; 
		for(int i=0; i < str.length(); i++) { 
			sum += str.charAt(i)-48; // �ƽ�Ű�ڵ��� '1' ��  49 �̹Ƿ� ���� ���ڿ� 48�����̳�
		} 
		System.out.println("sum="+sum);
		*/
		
		//4-10)
		/*
		int num = 12345;
		int sum = 0;
		int temp;
		
		for(int i = 1 ; i <= 5; i++) {
			temp = 1;
			for(int j = 1 ; j <= 5-i ; j++) {
				temp *= 10;
			}
			
			sum += num/temp;
			num = num-(num/temp)*temp;
		}
		
		System.out.println("sum="+sum);
		*/
		
		//4-11)
		/*
		int num1 = 1;
		int num2 = 1;
		int num3 = 0; 
		System.out.print(num1+","+num2); 
		
		for(int i = 0 ; i < 8 ; i++) {
			System.out.print(",");
			num3 = num1 + num2;
			num1 = num2;
			num2 = num3;
			System.out.print(num3);
		}
		*/
		
		//4-12)***************************
		/*
		for(int i = 2 ; i <= 9 ; i += 3) {
			for(int j = 1 ; j <=3 ; j++) {
				for(int k = 1; k <= 3 && (i+(k-1))< 10; k++) {
					System.out.print((i+(k-1)) + "*" + j + "=" + ((i+(k-1))*j) + "\t");
				}
				System.out.println();
			}	
			System.out.println();
		}
		*/
		
		//4-13)
		/*
		String value = "12o34"; 
		char ch = ' '; 
		boolean isNumber = true;
		
		for(int i=0; i < value.length() ;i++) { 
			if(value.charAt(i) >= '0' && value.charAt(i) <= '9') {
				continue;
			}
			else {
				isNumber = false;
				break;
			}
		} 
		if (isNumber) { 
			System.out.println(value+"�� �����Դϴ�."); 
		} else { 
			System.out.println(value+"�� ���ڰ� �ƴմϴ�."); 
		}
		*/
		
		//4-14)
		/*
		int answer = 45; 
		int input = 0; 
		int count = 0; 
		java.util.Scanner s = new java.util.Scanner(System.in); 
		do { 
			count++; 
			System.out.print("1�� 100���� �� �Է� :"); 
			input = s.nextInt(); 
			
			if(answer > input) {
				System.out.println("�� ū ���� �Է��ϼ���");
			}else if(answer < input) {
				System.out.println("�� ���� ���� �Է��ϼ���");
			}else {
				System.out.println("������ϴ�.");
				break;
			}
			
		} while(true); 
		System.out.println("�õ� Ƚ���� " + count + "�� �Դϴ�.");
		*/
		
		//4-15)
		/* 5�ڸ� �϶��� ����
		int number = 12321; 
		int tmp = number; //12321 -> result
		int result = 0; 
		
		while(tmp !=0) { 
			int i = 10000;
			int cnt = 5;
			while(i>=1) {
				if((tmp/i)!=0) {
					break;
					
				}
				else {
					i /= 10;
					cnt--;
				}
			}
			System.out.println("cnt : " + cnt);
			
			int num_digit = 1;
			int tmp_digit = 10000;
			for(int j = 1 ; j <= cnt-1 ; j++ ) {
				num_digit *= 10;
				tmp_digit /= 10;
			}
			
			System.out.println("num_digit : " + num_digit);
			System.out.println("tmp_digit : " +tmp_digit);
			
			result += (tmp/num_digit)*tmp_digit;
			tmp = tmp-((tmp/num_digit)*num_digit);
			
			//tmp = 0;
		} 
		System.out.println(result);
		if(number == result) 
			System.out.println( number + "�� ȸ���� �Դϴ� ."); 
		else 
			System.out.println( number + "�� ȸ������ �ƴմϴ�  ."); 
		*/
	}
}

package practice;

import java.text.*;
import java.util.*;

public class practice10 {
	public static void main(String args[]) {
		
		// 10-1)
		/*
		Calendar cal = Calendar.getInstance();
		for(int i = 0 ; i < 12 ; i++) {
			cal.set(2010,i,1);
			int end = cal.getActualMaximum(Calendar.DATE);
			int count = 0;
			int day2 = 0;
			for(int j = 1 ; j <= end ; j++) {
				cal.set(2010,i,j);
				int week = cal.get(Calendar.DAY_OF_WEEK);
				if(week == 1) {
					count++;
				}
				if(count == 2) {
					day2 = j;
					break;
				}
			}
			
			int year = cal.get(Calendar.YEAR);
			int mon = cal.get(Calendar.MONTH);
			
			System.out.println(year + " " + (mon+1) + " " + day2 + " ");
		}
		*/
		
		// 10-2)
		/*
		Calendar fromCal = Calendar.getInstance();
		Calendar toCal = Calendar.getInstance();
		fromCal.set(2010,0,1);
		toCal.set(2010,0,1);
		printResult(fromCal,toCal);
		fromCal.set(2010,0,21);
		toCal.set(2010,0,21);
		printResult(fromCal,toCal);
		fromCal.set(2010,0,1);
		toCal.set(2010,2,1);
		printResult(fromCal,toCal);
		fromCal.set(2010,0,1);
		toCal.set(2010,2,23);
		printResult(fromCal,toCal);
		fromCal.set(2010,0,23);
		toCal.set(2010,2,21);
		printResult(fromCal,toCal);
		fromCal.set(2011,0,22);
		toCal.set(2010,2,21);
		printResult(fromCal,toCal);
		*/
		
		// 10-3)
		/*
		String data = "123,456,789.5";
		System.out.println("data : " + data);
		String arr[] = data.split(","); //123 456 789.5
		Object num[] = new Object[arr.length];
		for(int i = 0 ; i < arr.length ; i++) {
			if(arr[i].indexOf(".") != -1) {
				double temp = Double.parseDouble(arr[i]);
				temp = Math.round(temp);
				num[i] = (int)temp;
			}else {
				num[i] = Integer.parseInt(arr[i]);
			}
		}
		System.out.print("�ݿø� : ");
		String temp = "";
		for(int i = 0 ; i < arr.length ; i++) {
			System.out.print(num[i]);
			temp += num[i];
		}
		System.out.print("\n������  : ");
		StringBuffer sb = new StringBuffer();
		
		for(int i = 1 ; i <= temp.length() ; i++) {
			sb.insert(0, temp.charAt(temp.length()-i));
			if(i%4==0) {
				sb.insert(0,",");
			}
		}
		System.out.println(sb);
		*/
		
		// 10-4) 10-7) 
		/*
		Scanner sc = new Scanner(System.in);
		System.out.print("��¥�Է�(�������̿� /Ȱ��)\n>> ");
		String str = sc.next();
		
		String temp[] = str.split("/");
		int arr[] = new int[temp.length];
		for(int i = 0 ; i < temp.length ; i++) {
			arr[i] = Integer.parseInt(temp[i]);
		}
		Calendar cal = Calendar.getInstance();
		
		cal.set(arr[0],arr[1]-1,arr[2]);
	
		int week = cal.get(Calendar.DAY_OF_WEEK);
				
		switch(week) {
		case 1:System.out.println("�Ͽ���"); break;
		case 2:System.out.println("������"); break;
		case 3:System.out.println("ȭ����"); break;
		case 4:System.out.println("������"); break;
		case 5:System.out.println("�����"); break;
		case 6:System.out.println("�ݿ���"); break;
		case 7:System.out.println("�����"); break;
		}
		*/
		
		// 10-5) 10-6) 10-8)(�ð�)
		//System.out.println(getDayDiff("20010103","20010101"));
		//System.out.println(getDayDiff("20010103","20010103"));
		//System.out.println(getDayDiff("20010103","200103"));
		System.out.println(getDayDiff("20010000","20000000"));

	
	}
	
	// 10-5) 10-6) 10-8)(�ð�)
	static int getDayDiff(String a,String b) {
		
		if(a.length() != 8 || b.length() != 8) {
			return 0;
		}
		else {
			String year1 = "",year2 = ""; 
			String mon1 = "",mon2 = "";
			String day1 = "",day2 = "";
			int data1 = Integer.parseInt(a);
			int data2 = Integer.parseInt(b);
			
			if(data1 > data2) { //data2�� ��ŭ
				int temp = data1;
				String tmp = a;
				data1 = data2;
				a = b;
				data2 = temp;
				b = tmp;
			}else if(data1 == data2) {
				return 0;
			}
			
			for(int i = 0 ; i < 8 ; i++) {
				if(i<4) {
					year1 += a.charAt(i);
					year2 += b.charAt(i);
				}else if(i < 6) {
					mon1 += a.charAt(i);
					mon2 += b.charAt(i);
				}else {
					day1 += a.charAt(i);
					day2 += b.charAt(i);
				}
			}
			
			int year3 = Integer.parseInt(year1);
			int year4 = Integer.parseInt(year2);
			int mon3 = Integer.parseInt(mon1);
			int mon4 = Integer.parseInt(mon2);
			int day3 = Integer.parseInt(day1);
			int day4 = Integer.parseInt(day2);
			
			int year = year4 - year3;
			int mon = mon4 - mon3;
			int day = day4 - day3;
			
		
			return 0;
			
			/*
			�⵵�� ������ ũ��
			2000 01 01
			1999 12 31

			1 -11 -30

			2000 01 01
			2000 01 02

			0 0 1
		 */
		}
	}
	// 10-2)
	/*
	static int paycheckCount(Calendar from,Calendar to) {
		
		if(from == null || to == null) {
			return 0;
		}
		if(from == to && to.get(Calendar.DATE) == 21) {
			return 1;
		}
		int monDiff = (to.get(Calendar.MONTH) - from.get(Calendar.MONTH));
		if(monDiff < 0 || (to.get(Calendar.YEAR) < from.get(Calendar.YEAR))) {
			return 0;
		}//�⵵�� ������ �� Ŀ�� -�� �ɰ�쵵 �����ߴ�.
		if(from.get(Calendar.DAY_OF_MONTH) <= 21 && to.get(Calendar.DAY_OF_MONTH) >= 21) {
			monDiff++;
		}
		if(from.get(Calendar.DAY_OF_MONTH) > 21 && to.get(Calendar.DAY_OF_MONTH) < 21) {
			monDiff--;
		}
		return monDiff;
	}
	static void printResult(Calendar from,Calendar to){
		Date fromDate=from.getTime();
		Date toDate = to.getTime(); 
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		System.out.print(sdf.format(fromDate)+" ~ " + sdf.format(toDate)+":");
		System.out.println(paycheckCount(from,to));
	}
	*/
}

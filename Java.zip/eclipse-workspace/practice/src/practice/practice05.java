package practice;

import java.util.Scanner;

public class practice05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// 5-1) 
		//int[] arr[]; 
		//int[] arr = {1,2,3,}; 
		//int[] arr = new int[5]; 
		//int[] arr = new int[5]{1,2,3,4,5}; ->���� �迭 ����� ����ϴ����� ������ �߸� ��
		//int arr[5]; -> ���� null���� ����		 ->new int[5]; or new int[]{~};
		//int[] arr[] = new int[3][];
		
		// 5-2) 2
		
		// 5-3)
		/*
		int[] arr = {10, 20, 30, 40, 50}; 
		int sum = 0;
		
		for(int i = 0 ; i <arr.length ; i++) {
			sum += arr[i];
		}
		
		System.out.println("sum="+sum);
		 */
		
		//5-4)
		/*
		int[][] arr = { { 5, 5, 5, 5, 5}, 
						{10,10,10,10,10}, 
						{20,20,20,20,20}, 
						{30,30,30,30,30} }; 
		int total = 0; 
		float average = 0;

		int cnt = 0;
		for(int i = 0 ; i <arr.length; i++) {
			for(int j = 0 ; j < arr[i].length ; j++) {
				total += arr[i][j];
				cnt++;
			}
		}
		average = (float)total/cnt;
		
		System.out.println("total="+total); 
		System.out.println("average="+average); 
		*/
		// 5-5)
		/*
		int[] ballArr = {1,2,3,4,5,6,7,8,9}; 
		int[] ball3 = new int[3];
		
		for(int i=0; i< ballArr.length;i++) { 
			int j = (int)(Math.random() * ballArr.length); 
			int tmp = 0;
			
			int k = (int)(Math.random() * ballArr.length);
			
			tmp = ballArr[j];
			ballArr[j] = ballArr[k];
			ballArr[k] = tmp;
			
		}
		
		for(int i = 0 ; i < 3; i++) {
			ball3[i] = ballArr[i];
		}
		
		for(int i=0;i<ball3.length;i++) { 
			System.out.print(ball3[i]); 
		} 
		*/
		//5-6)
		/*
		int[] coinUnit = {500, 100, 50, 10}; 
		int money = 3000; 
		System.out.println("money="+money); 
		
		for(int i=0;i<coinUnit.length;i++) { 
			System.out.println(coinUnit[i] + "��: " + money/coinUnit[i]);
			money = money-((money/coinUnit[i])*coinUnit[i]);
		} 
		*/
		//5-7)
		/*
		if(args.length!=1) { 
			System.out.println("USAGE: java Exercise5_7 3120"); 
			System.exit(0); 
		}
		int money = Integer.parseInt(args[0]); 
		System.out.println("money="+money); 
		
		int[] coinUnit = {500, 100, 50, 10 };
		int[] coin = {5, 5, 5, 5};
		
		for(int i=0;i<coinUnit.length;i++) { 
			int coinNum = 0;
			
			coinNum = money/coinUnit[i];
			if(money/coinUnit[i] > coin[i]) {
				coin[i] = 0;
				money = money-((5)*coinUnit[i]);
				System.out.println(coinUnit[i]+" : "+5);
			}else {
				coin[i] -= money/coinUnit[i];
				money = money- ((money/coinUnit[i])*coinUnit[i]);
				System.out.println(coinUnit[i]+" : "+coinNum);
			}
		} 
	
		if(money > 0) {
			System.out.println("�Ž������� �����մϴ� ."); 
			System.exit(0); 
		}
		System.out.println("= ���� ������ ����  ="); 
	
		for(int i=0;i<coinUnit.length;i++) { 
			System.out.println(coinUnit[i]+"��  :"+coin[i]); 
		} 
		*/
		//5-8)
		/*
		int[] answer = { 1,4,4,3,1,4,4,2,1,3,2 }; 
		int[] counter = new int[4]; 
		
		for(int i=0; i < answer.length;i++) { 
			switch(answer[i]) {
			case 1: counter[0]++; break;
			case 2: counter[1]++; break;
			case 3: counter[2]++; break;
			case 4: counter[3]++; break;
			}
		} 
		for(int i=0; i < counter.length;i++) { 
			
			System.out.print(counter[i]);
			
			for(int j = 0 ; j < counter[i] ; j++) {
				System.out.print("*");
			}
			
			System.out.println(); 
		} 
		*/
		//5-9)
		/*
		char[][] star = { {'*','*',' ',' ',' '}, 
						  {'*','*',' ',' ',' '}, 
						  {'*','*','*','*','*'}, 
						  {'*','*','*','*','*'} };
	
		char[][] result = new char[star[0].length][star.length]; 
	
		for(int i=0; i < star.length;i++) { 
			for(int j=0; j < star[i].length;j++) { 
				System.out.print(star[i][j]); 
			} 
			System.out.println(); 
		} 
		
		System.out.println(); 
		
		for(int i=0; i < star.length;i++) { 
			for(int j=0; j < star[i].length;j++) { 				
				if(i == 0) {
					result[j][3] = star[i][j]; 
				}
				if(i == 1) {
					result[j][2] = star[i][j]; 
				}
				if(i == 2) {
					result[j][1] = star[i][j]; 
				}
				if(i == 3) {
					result[j][0] = star[i][j]; 
				}
			}
		}
		
		for(int i=0; i < result.length;i++) { 
			for(int j=0; j < result[i].length;j++) { 
				System.out.print(result[i][j]);
			}
			System.out.println();
		}
		*/
		//5-10)
		/*
		char[] abcCode = 
				{ '`','~','!','@','#','$','%','^','&','*',
				'(',')','-','_','+','=','|','[',']','{',
				'}',';',':',',','.','/'}; 
		char[] numCode = {'q','w','e','r','t','y','u','i','o','p'}; 
		
		String src = "abc123"; 
		String result = "";
		
		
		for(int i=0; i < src.length();i++) { 
			char ch = src.charAt(i); 
			
			if(ch >= '0' && ch <= '9') {
				result += numCode[(int)ch-48];
			}else {
				result += abcCode[(int)ch-97];
			}
			
		} 
		
		System.out.println("src:"+src); 
		System.out.println("result:"+result); 
		*/
		//5-11)
		/*
		int[][] score = {
				{100, 100, 100} ,
				{20, 20, 20} ,
				{30, 30, 30} ,
				{40, 40, 40} ,
				{50, 50, 50} }; 
		int[][] result = new int[score.length+1][score[0].length+1]; 
		for(int i=0; i < score.length;i++) {
			for(int j=0; j < score[i].length;j++) {
				result[i][j] = score[i][j]; result[i][score[0].length] += result[i][j]; 
				result[score.length][j] += result[i][j]; result[score.length][score[0].length] += result[i][j]; 
			} 
		}
		
		for(int i=0; i < result.length;i++) {
			for(int j=0; j < result[i].length;j++) {
				System.out.printf("%4d",result[i][j]); 
			} 
			System.out.println(); 
		} 
		*/
		//5-12)
		/*
		Scanner sc = new Scanner(System.in);
		
		String test[] = {"chair","computer","integer"};
		String answer[] = {"����","��ǻ��","����"};
		int cnt = 0;
		
		for(int i = 0 ; i < test.length ; i++) {
			System.out.print(test[i] + "�� ����? > ");
			String str = sc.next();
			
			if(str.equals(answer[i])) {
				System.out.println("�����Դϴ�");
				cnt++;
			}else {
				System.out.println("Ʋ�Ƚ��ϴ�. ������" + answer[i] + "�Դϴ�.");
			}
		}
		
		System.out.println("��ü " + test.length + "���� �� " + cnt + "���� ���߼̽��ϴ�." );
		*/		
		//5-13)
		/*
		String[] words = { "television", "computer", "mouse", "phone" };
		Scanner scanner = new Scanner(System.in); 
		for(int i=0;i<words.length;i++) {
			char[] question = words[i].toCharArray();
			
			for(int j = 0 ; j < question.length ; j++) {
				int index = (int)((Math.random()) * question.length);
				char tmp = question[index];
				question[index] = question[j];
				question[j] = tmp;
			}
			
			System.out.printf("Q%d. %s�� ������ �Է��ϼ��� .>", i+1, new String(question)); 
			
			String answer = scanner.nextLine();
			
			if(words[i].equals(answer.trim())) 
				System.out.printf("�¾ҽ��ϴ� .%n%n"); 
			else 
				System.out.printf("Ʋ�Ƚ��ϴ�.%n%n");

		}
	*/
	}
}

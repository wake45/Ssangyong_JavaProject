package practice;

// 6-1) 6-2)
/*
class SutdaCard {
	private int num;
	private boolean isKwang;
	
	SutdaCard(){
		this.num = 1;
		this.isKwang = true;
	}
	
	SutdaCard(int num,boolean isKwang){
		this.num = num;
		this.isKwang = isKwang;
	}
	
	public int setNum() {		
		return num;
	}
	public void getNum(int num) {
		this.num = num;
	}
	
	public String info() {
		return num + ((isKwang==true)?"K":" ")
				;
	}
}
*/

// 6-3) 6-4) 6-5)
/*
class Student{
	private String name;
	private int ban;
	private int no;
	private int kor;
	private int eng;
	private int math;
		
	Student(String name,int ban,int no,int kor,int eng,int math){
		this.name = name;
		this.ban = ban;
		this.no = no;
		this.kor = kor;
		this.eng = eng;
		this.math = math;
	}
	
	public String getName() {
		return name;
	}
	
	public int getTotal(){
		return kor + eng + math;
	}
	public float getAverage() {
		return Math.round((kor + eng + math)/3.0F*100)/100.0F;
	}
	public String info() {
		return name + ","+ 
				ban + ","+ 
				kor + ","+ 
				eng + ","+ 
				math + ","+ 
				kor + eng + math + ","+ 
				Math.round((kor + eng + math)/3.0F*100)/100.0F; 
	}
}
*/


//6-7)
/*
class MyPoint{
	int x;
	int y;
	
	MyPoint(int x, int y){
		this.x = x;
		this.y = y;
	}
	
	double getDistance(int x1, int y1) {
		return Math.sqrt(Math.pow(x-x1,2) + Math.pow(y-y1,2));
	}
}
*/

/* 6-9)
class PlayingCard{
	int kind;
	int num;
	
	static int width;
	static int height;
	
	PlayingCard(int k, int n){
		kind = k;
		num = n;
	}
	
	public static void main(String args[]) {
		PlayingCard card = new PlayingCard(1,1);
	}
}

//Ŭ���� ����(static����): width , height
//�ν��Ͻ� ���� : kind , num
//���� ���� : card
*/

// 6-10) b,c,d,e -> b,e //c,d:������ �ϳ��̻� �־�ߵ� 

// 6-11) d -> b //�ν��Ͻ� �޼��忡�� ��밡�� //static �޼��忡���� ���Ұ�

// 6-12) c,d

// 6-13) b,c -> b,c,d //a:�Ű������� �ڷ����� ��ȯŸ�� ���� �ϳ��� �޶�ߵ�

// 6-14) a,c,e -> c,e //a:�������� �ڵ��ʱ�ȭ��

// 6-15) a	

// 6-16) a,c -> a,e //e:stack������ ������

// 6-17) b,f -> b 

// 6-18) 
/*
class MemberCall { 
	int iv = 10; 
	static int cv = 20; 
	int iv2 = cv; 
	//static int cv2 = iv; //���������� ���������� �ƴ� ������ �ʱ�ȭ�� �� �� ����
	static int cv2 = 20;
	
	static void staticMethod1() { 
		System.out.println(cv); 
		//System.out.println(iv); //�����޼ҵ忡���� �ν��Ͻ� ������ ����� �� ����.
	} 
	
	void instanceMethod1() {
		System.out.println(cv);
		System.out.println(iv);
	} 
	
	static void staticMethod2() {
		staticMethod1(); 
		//instanceMethod1();  //���� �޼ҵ忡���� �ν��Ͻ� �޼ҵ带 ����� �� ����.
	} 
	void instanceMethod2() {
		staticMethod1(); 
		instanceMethod1(); 
	} 
}
*/

// 6-21) �ƴϾ��� ������ �߸��ż� ���� ���
/*
class MyTv {
	boolean isPowerOn; 
	int channel;
	int volume;
	
	final int MAX_VOLUME = 100;
	final int MIN_VOLUME = 0;
	final int MAX_CHANNEL = 100;
	final int MIN_CHANNEL = 1;
	
	void turnOnOff() {
		if(isPowerOn == true) {
			isPowerOn = false;
		}
		else {
			isPowerOn = true;
		}
	}
	void volumeUp() {
		if(volume < MAX_VOLUME) {
			volume++;
		}
	}
	void volumeDown() {
		if(volume > MIN_VOLUME) {
			volume--;
		}
	}
	void channelUp() {
		if(channel == MAX_CHANNEL) {
			channel = MIN_CHANNEL;
		}else {
			channel++;
		}
	}
	void channelDown() {
		if(channel == MIN_CHANNEL) {
			channel = MAX_CHANNEL;
		}
		else {
			channel--;
		}
	}
}
*/

public class practice06 {
	
	public static void main(String[] args) {
	
		// 6-2)
		/*
		SutdaCard card1 = new SutdaCard(3,false);
		SutdaCard card2 = new SutdaCard();
		
		System.out.println(card1.info());
		System.out.println(card2.info());
		*/
		
		// 6-4) 6-5)
		/*
		Student s = new Student("ȫ�浿",1,1,100,60,76);
		
		System.out.println("�̸� : " + s.getName());
		System.out.println("���� : " + s.getTotal());
		System.out.println("��� : " + s.getAverage());
		System.out.println(s.info());
		*/
		
		// 6-6)
		//System.out.println(getDistance(1,1,2,2));
		
		// 6-7)
		/*
		MyPoint p = new MyPoint(1,1);
		System.out.println(p.getDistance(2,2));
		*/
		
		// 6-19)
		/*
		String str = "ABC123"; 
		System.out.println(str); 
		change(str); 
		System.out.println("After change:"+str);
		*/

		// 6-20)
		/*
		int[] original = {1,2,3,4,5,6,7,8,9}; 
		System.out.println(java.util.Arrays.toString(original)); 
		int[] result = shuffle(original); 
		System.out.println(java.util.Arrays.toString(result));
		*/
		
		// 6-21)
		/*
		MyTv t = new MyTv(); 
		t.channel = 100; 
		t.volume = 0; 
		System.out.println("CH:"+t.channel+", VOL:"+ t.volume); 
		t.channelDown(); t.volumeDown(); 
		System.out.println("CH:"+t.channel+", VOL:"+ t.volume); 
		t.volume = 100; t.channelUp(); t.volumeUp(); 
		System.out.println("CH:"+t.channel+", VOL:"+ t.volume);
		*/
		
		// 6-22)
		/*
		String str = "123";
		System.out.println(str+"�� �����Դϱ�?" + isNumber(str));
		
		str = "1234o";
		System.out.println(str+"�� �����Դϱ�?" + isNumber(str));
		*/
		
		// 6-23)
		/*
		int[] data = {3,2,9,4,7}; 
		System.out.println(java.util.Arrays.toString(data)); 
		System.out.println("�ִ밪 : "+ max(data)); 
		System.out.println("�ִ밪 : "+ max(null)); 
		System.out.println("�ִ밪 : "+ max(new int[] {}));
		*/
		
		// 6-24)
		/*
		int value = 5;
		System.out.println(value+"�� ���밪  :"+abs(value));
		value = -10; 
		System.out.println(value+"�� ���밪  :"+abs(value));
		*/

	}
	// 6-6)
	/*
	static double getDistance(int x , int y, int x1, int y1) {
		return Math.sqrt(Math.pow(x-x1,2) + Math.pow(y-y1,2));
	}
	*/
	
	// 6-19)
	/*
	public static void change(String str) {
		str += "456"; 
	} 
	//"ABC123"
	//"ABC123" �ν��Ͻ� ������ ���� ������� �ʴ´�.
	*/
	
	// 6-20)
	/*
	public static int[] shuffle(int[] original) {
		
		for(int i = 0 ; i < original.length ; i++) {
			int index1 = (int)(Math.random()*original.length);
			int index2 = (int)(Math.random()*original.length);
			if(index1 == index2) {
				i--;
				continue;
			}
			else {
				int temp = original[index1];
				original[index1] = original[index2];
				original[index2] = temp;
			}
		}
		
		return original;
	}
	*/
	
	// 6-22)
	/*
	public static boolean isNumber(String str) {
		boolean bul = true;
		
		for(int i = 0 ; i < str.length() ; i++) {
			if(!(str.charAt(i) >= '0' && str.charAt(i) <= '9')) {
				bul = false;
				break;
			}
		}
		
		return bul;
	}
	*/
	
	// 6-23)
	/*
	public static int max(int[] arr) {
		
		if(arr == null || arr.length == 0) {
			return -999999;
		}
		int num = 0;
		for(int i = 0 ; i < arr.length ; i++) {

			if(num < arr[i]) {
				num = arr[i];
			}
		}
		
		return num;
	}
	*/
	
	// 6-24)
	/*
	public static int abs(int value) {
		if(value < 0) {
			return -value;
		}
		else {
			return value;
		}
	}
	*/
}


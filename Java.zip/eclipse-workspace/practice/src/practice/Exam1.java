package practice;

import java.util.Scanner;

public class Exam1 {
	public static void print(String arr[][]) { //�迭 ��� �޼ҵ�
		for(int i = 0 ; i < arr.length ; i++) {
			for(int j = 0 ; j < arr[i].length ; j++)
				System.out.print(arr[i][j] + " ");
			System.out.println();
		}
	}
	public static String[][] border(String arr[][]){ //@ �׵θ� �׸��� �޼ҵ�
		for(int i = 0 ; i < arr.length ; i++) {
			for(int j = 0 ; j < arr[i].length ; j++) {
				if(i == 0 || i == 17) 
					arr[i][j] = "@";
				else if(j == 0 || j == 17) 
					arr[i][j] = "@";
			}
		}
		return arr;
	}
	public static String[][] menu1(String arr[][]) { // �ݽð� ���� ȸ�� �޼ҵ�
		System.out.println("\t�ݽð� ���� ȸ��");
		String tmp[][] = new String[18][18];
		for(int i = 1 ; i < arr.length-1 ; i++) 
			for(int j = 1 ; j < arr[i].length-1 ; j++) 
				tmp[i][j] = arr[j][17-i]; 	
		
		arr = tmp;
		arr = border(arr);
		return arr;
	}
	public static String[][] menu2(String arr[][]) { // �ð� ���� ȸ�� �޼ҵ�
		System.out.println("�ð���� ȸ��");
		String tmp[][] = new String[18][18];
		
		for(int i = 1 ; i < arr.length-1 ; i++)  
			for(int j = 1 ; j < arr[i].length-1 ; j++)  
				tmp[i][j] = arr[17-j][i]; 
				
		arr = tmp;
		border(arr);
		return arr;
	}
	public static String[][] menu3(String arr[][]) { // ���� ����Ʈ���� �޼ҵ�
		System.out.println("\t���� ����Ʈ����");
		int count[] = new int[16];
		for(int i = 1 ; i < arr.length-1 ; i++) {
			for(int j = 1 ; j < arr[i].length-1 ; j++) {
				if(arr[i][j] == "��") 
					count[j-1]++;
			}
		}
		for(int i = arr.length-2 ; i >= 1 ; i--) {
			for(int j = 1 ; j < arr[i].length-1 ; j++) {
				if(count[j-1] != 0) {
					arr[i][j] = "��";
					count[j-1]--;
				}
				else 
					arr[i][j] = "��";
			}
		}
		return arr;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String arr[][] = new String[18][18];
		for(int i = 0 ; i < arr.length ; i++) {
			for(int j = 0 ; j < arr[i].length ; j++) {
				if(i == 0 || i == 17)
					arr[i][j] = "@";
				else if(j == 0 || j == 17) 
					arr[i][j] = "@";
				else {
					int temp = (int)(Math.random()*2);
					if(temp == 0)
						arr[i][j] = "��";
					else 
						arr[i][j] = "��";
				}
			}
		}

		loop : while(true) {
			print(arr);
			System.out.println("\n1.�ݽð� ���� ȸ��\t2.�ð���� ȸ��\t3.���� ����Ʈ����\t4.����");
			System.out.print("�޴��� �Է��Ͻÿ� > ");
			int menu = sc.nextInt();
			switch(menu) {
			case 1: 
				arr = menu1(arr);
				continue loop;
			case 2: 
				arr = menu2(arr);
				continue loop;
			case 3: 
				arr =  menu3(arr);
				continue loop;
			case 4: 
				System.out.println("���� �Ǿ����ϴ�.");
				break loop;
			}
		}
	}
}

package practice;

public class practice03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 2;
		int y = 5;
		char c= 'A';
		// 3-1)
		/* 6
		 * false
		 * 13
		 * 5 
		 * false
		 * 2
		 * 5
		 * 66
		 * 66 B // ���� ������ , ���� �������� ������ �ڷ����� �ٲ��� ����
		 * 66 B
		 * 67 C
		 */
		
		// 3-2) (numOfApples%10)!=0 ? (numOfApples+10)/10 : numOfApples/10
		
		// 3-3) num==0 ? "0" : ((num%10)==0 ? "���" : "����)
		
		// 3-4) num-(num%100)
		
		// 3-5) num-((num-((num/100)*100))-(((num-((num/100)*100))/10)*10))+1
		
		// 3-6) num%10!=0? ((num-(num%10))+10)-num : 0

		// 3-7) 5F/9F*(fahrenheit-32)
		
		// 3-8) 
		/*
		byte a = 10; 
		byte b = 20; 
		byte c = (byte)(a + b); 
		char ch = 'A'; 
		ch = (char)(ch + 2); 
		float f = 3/2; 
		long l = 3000 * 3000 * 3000; 
		float f2 = 0.1f; 
		double d = 0.1; 
		boolean result = d == f2; 
		System.out.println("c="+c); 
		System.out.println("ch="+ch); 
		System.out.println("f="+f); 
		System.out.println("l="+l); 
		System.out.println("result="+result);
		*/

		// 3-9) (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9')? true:false
				
		// 3-10) ch >= 'A' && ch <= 'Z' // (char)(ch+32)
		
	}

}

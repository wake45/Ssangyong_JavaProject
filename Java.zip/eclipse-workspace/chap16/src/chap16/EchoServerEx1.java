package chap16;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;
import java.util.Set;

import java.util.*;

public class EchoServerEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 5000;
		Socket client = null;
		ServerSocket server = null;
		try {
			server = new ServerSocket(port);
			System.out.println("server �غ��");
			client = server.accept();
			
			PrintWriter out =  new PrintWriter(client.getOutputStream(),true);
			BufferedReader in =  new BufferedReader(new InputStreamReader(client.getInputStream()));
			String input;
			
			int result[] = new int[3];
			
			for(int i = 0 ; i < 3 ; i++) {
				result[i] = (int)(Math.random()*10);
			}
			
			out.println("���� ���ڸ� �Է����ּ��� ������");
			out.flush();
			
			while((input = in.readLine()) != null) {
				int num = Integer.parseInt(input);
				int hun = num/100;
				int ten = (num - hun*100)/10;
				int one = (num - hun*100 - ten*10);
				int strike = 0; int ball = 0;
			
				System.out.println(result[0] + "," + result[1] + "," + result[2]);
				
				for(int i = 0 ; i < 3 ; i++) {
					if(result[i] == hun || result[i]  == ten || result[i]  == one ) {
						strike++;
					}else {
						ball++;
					}
				}

				out.println("strike : " + strike + " ball : " + ball);
		
				out.flush();
			}
			in.close();
			out.close();
			client.close();
			server.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
}

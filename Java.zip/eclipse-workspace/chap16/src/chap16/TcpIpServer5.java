package chap16;

import java.net.ServerSocket;
import java.net.Socket;

public class TcpIpServer5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocket serverSocket = null;
		Socket socket = null;
		try {
			serverSocket = new ServerSocket(7777);
			System.out.println("������ �غ��");
			socket = serverSocket.accept();
			Sender sender = new Sender(socket);
			Receiver receiver = new Receiver(socket);
			sender.start();
			receiver.start();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}

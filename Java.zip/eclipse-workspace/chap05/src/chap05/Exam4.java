package chap05;

public class Exam4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = new int[10];
		
		for(int i = 0 ; i < num.length ; i++) {
			num[i] = (int)(Math.random()*100)+1;
		}

		for(int i = 0 ; i < num.length ; i++) {
			for(int j = 0 ; j < num.length-1 ; j++) {
				if(num[j] > num[j+1]) {
					int temp = num[j];
					num[j] = num[j+1];
					num[j+1] = temp;
				}
			}
		}
		
		for(int i = 0 ; i < num.length ; i++) {
			System.out.print(num[i] + " ");
		}
	}

}

package chap05;

public class Exam3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int arr[] = {1,2,3,4,5,6,7,8,9};
		int[] nums = new int[3];
		
		for(int i = 0 ; i < nums.length ; i++) {
			
			loop : while(true) {
				int temp = (int)(Math.random()*9)+1;
				for(int j = 0 ; j < nums.length ; j++) {
					if(nums[j] == temp) {
						continue loop;
					}
					if(j == 2) {
						nums[i] = temp;
					}
				}
				break;
			}
		}
		
		for(int i : nums) {
			System.out.print(i + " ");
		}
	}

}

package chap05;

import java.util.Scanner;

public class Exam7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = Integer.parseInt(args[0]);
	
		for(int i = 1 ; i <= Math.sqrt(num) ; i++) {
			if(num%i == 0) {
				System.out.print(i + " "+ num/i + " ");
			}
		}
	}

}

package chap05;

import java.util.Scanner;

public class Exam11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] coin = { 500, 100, 50, 10, 5, 1};
		int[] cnt = {5,5,5,5,5,5};
		
		Scanner sc = new Scanner(System.in);
		System.out.print("���� �Է� :");
		int num = sc.nextInt();
		int coin_use[] = new int[coin.length];
		
		for(int i = 0 ; i < coin.length ; i++) {
			if(num/coin[i] <= cnt[i]) {
				coin_use[i] = num/coin[i];
				num -= (coin[i]*(num/coin[i]));
				cnt[i] -= coin_use[i];
			}
			else {
				coin_use[i] = 5;
				num -= coin[i]*5;
				cnt[i] -= coin_use[i];
			}
			if(num <= 0) {
				break;
			}
			if(i == coin.length-1) {
				System.out.println("������ �����մϴ�");
			}
		}
		
		
		for(int j = 0 ; j < coin_use.length ; j++) {
			System.out.println(coin[j] + "�� : " + coin_use[j]);
		}
	}

}

package chap05;

public class Exam8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length != 2) {
			System.out.println("command line�� �ΰ��� �Ķ���͸� �Է��ϼ���");
			System.out.println("java Exam8 10 20");
			return;
		}
		
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		
		for(int i = 1 ; i <= ((num1<num2)?num1:num2) ; i++) {
			if(num1%i == 0 && num2%i == 0) {
				System.out.print(i + " ");
			}
		}
	}

}

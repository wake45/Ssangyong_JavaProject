package chap05;

public class Exam12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if(args.length == 0) {
			System.out.println("�Է��϶�ϱ�;;");
			return;
		}
		
		int num = Integer.parseInt(args[0]);
		
		if(num == 2) {
			System.out.println("�Ҽ��� ����");
			return;
		}
		for(int i = 2 ; i < num ; i++) {
			if(num%i == 0) {
				System.out.println("�Ҽ� �ƴ�");
				break;
			}
			if(i == num-1) {
				System.out.println("�Ҽ��� ����");
			}
		}
	}

}

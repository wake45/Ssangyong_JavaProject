package chap05;

import java.util.Scanner;

public class Exam5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int[] octal = new int[32];
		System.out.println("8������ ��ȯ �� 10������ �Է��ϼ���");
		int num = sc.nextInt();
		
		int i = octal.length-1;
		while(num != 0) {
			octal[i] = num%8;
			num = num / 8 ;
			i--;
		}
		
		for(i = 0 ; i < octal.length ; i++) {
			System.out.print(octal[i] + "");
		}
	}

}

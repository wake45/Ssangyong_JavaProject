package chap05;

public class ArrayEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr1;
		int arr2[];
		
		arr1 = new int[5];
		arr2 = new int[5];
		
		arr1[0] = 10;
		arr1[1] = 20;
		arr1[2] = 30;
		
		arr2 = arr1;
		arr2[4] = 50;
		
		System.out.println("arr1 �迭 : ");
		for(int i=0; i <arr1.length ; i++) {
			System.out.println("arr1[" + i + "]=" + arr1[i]);}
		System.out.println("arr2 �迭 : ");
		for(int i=0;i<arr2.length;i++) {
			System.out.println("arr[" + i + "]=" + arr2[i]); }
		System.out.println("������ for������ �̿��� ���");
		
		for(int a : arr1) {System.out.println(a);}
	}

}

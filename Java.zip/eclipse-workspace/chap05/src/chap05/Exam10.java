package chap05;

public class Exam10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int score[][] = {{100,90,80},
						 {80,95,100},
						 {60,65,70},
						 {85,70,75},
						 {90,90,80}};
		int total[] = new int[3];
		double avg[] =  new double[3];
		int st_total[] = new int[5];
		double st_avg[] = new double[5];
		
		for(int i = 0 ; i < total.length ; i++) {
			total[i] = score[0][i] + score[1][i] + score[2][i] + score[3][i] + score[4][i];
			avg[i] = total[i]/5.0;
		}
		for(int i = 0 ; i < score.length ; i++) {
			st_total[i] = score[i][0] + score[i][1] + score[i][2];
			st_avg[i] = Math.round(st_total[i]/3.0);
		}
		
		System.out.println("�л�\t����\t����\t����\t�л�����\t�л����");
		for(int i = 0 ; i < score.length ; i++) {
			System.out.print((i+1) + "�� �л� :\t");
			for(int j = 0 ; j < score[i].length ; j++) {
				System.out.print(score[i][j] + "\t");
			}
			System.out.print(st_total[i] + "\t" + st_avg[i]);
			System.out.println();
		}
		System.out.print("�� �� :\t");
		for(int i = 0 ; i < total.length ; i++) {
			System.out.print(total[i] + "\t");
		}
		System.out.println();
		System.out.print("�� ��� :\t");
		for(int i = 0 ; i < avg.length ; i++) {
			System.out.print(avg[i] + "\t");
		}
	}

}

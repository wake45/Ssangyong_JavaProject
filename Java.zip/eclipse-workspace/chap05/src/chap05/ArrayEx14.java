package chap05;

import java.util.Arrays;

public class ArrayEx14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int score[] = {90,80,70};
		int score2[] = {1,2,3,4,5,};
		score2 = Arrays.copyOf(score,2);
		for(int s : score2) {
			System.out.println(s);
		}
		
		System.out.println("Arrays.toString(score2)");
		System.out.println(Arrays.toString(score2));
	}

}

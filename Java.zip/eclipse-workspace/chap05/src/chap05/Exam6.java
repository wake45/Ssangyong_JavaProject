package chap05;

import java.util.Scanner;

public class Exam6 {
	public static void main(String[] args) {
		char[] data = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
		char[] h = new char[32];
		for(int i = 0 ; i < h.length ; i++) {
			h[i] = '0';
		}
		
		System.out.println("16������ ��ȯ �� 10������ �Է��ϼ���");
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		
		int i = h.length-1;
		while(num != 0) {
			h[i] = (char)data[num % 16];
			num = num/16;
			i--;
		}
		
		for(i = 0 ; i < h.length ; i++) {
			System.out.print(h[i]);
		}
	}
}

package chap05;

public class ArrayEx4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

package chap05;

import java.util.Scanner;

public class Exam9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int answer[] = new int[4];
		
		int k = 0;
		loop : while (true) {
			int tmp = (int)(Math.random()*10)+1;
			for(int j = 0 ; j < answer.length ; j++) {
				if(answer[j] == tmp) {
					continue loop;
				}
				if(j == answer.length-1) {
					answer[k] = tmp;
				}
			}
			k++;
			if(k ==  answer.length) {
				break;
			}
		}
		
		for(int i : answer) {
			System.out.print(i + " ");
		}
		
		Scanner sc = new Scanner(System.in);
		int result[] = new int[4];
		int cnt = 0;
		
		System.out.println("\n���� �ٸ� �� 4�ڸ��� �Է��Ͻÿ�(1~9)");
		for(int i = 0 ; i < answer.length ; i++) {
			result[i] = sc.nextInt();
		}
		
		for(int i = 0 ; i < answer.length; i++) {
			if(answer[i] == result[i]) {
				System.out.println("��Ʈ���");
				cnt++;
				continue;
			}
			for(int j = 0 ; j < answer.length ; j++) {
				if(answer[j] == result[i]) {
					System.out.println("��");
					break;
				}
				if(j == answer.length-1) {
					System.out.println("������");
				}
			}
		}
		
		if(cnt == 4) {
			System.out.println("����");
		}
	}

}

package chap05;

public class Exam13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[][] = {{1},
				{10,20},
				{30,40,50},
				{60,70,80,90},
				{60,70,80,90,100}};
		int rowtotal[] = new int[arr.length];

		int max = 0;
		int cnt = 0;
		for(int i = 0 ; i < arr.length ; i++) {
			cnt = 0;
			for(int j = 0 ; j < arr[i].length ; j++) {
				rowtotal[i] += arr[i][j];
				cnt++;
			}
			if(max < cnt) {
				max = cnt;
			}
		}
		int coltotal[] = new int[max];
		for(int i = 0 ; i < arr.length ; i++) {
			for(int j = 0 ; j < arr[i].length ; j++) {
				coltotal[j] += arr[i][j];
			}
		}
		
		for(int i = 0 ; i < rowtotal.length ; i++) {
			System.out.println(i + "���� : " + rowtotal[i] + " ");
		}
		for(int i = 0 ; i < coltotal.length ; i++) {
			System.out.println(i + "���� : " + coltotal[i] + " ");
		}
	}

}

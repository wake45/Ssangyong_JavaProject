package chap05;

import java.util.Scanner;

public class Exam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int arr[] = new int[5];
		int sum = 0;
		double avg = 0.0;
		int max = 0;
		int min = 100;
		
		for(int i = 0 ; i < arr.length ; i++) {
			System.out.println("5���� ������  �Է� : ");
			arr[i] = sc.nextInt();
			sum += arr[i];
			avg = (double)sum/arr.length;
			
			if(max < arr[i]) {
				max = arr[i];
			}
			if(min > arr[i]) {
				min = arr[i];
			}
		}
		
		System.out.println("�հ� : " + sum);
		System.out.println("��� : " + avg);
		System.out.println("�ִ����� : " + max);
		System.out.println("�ּ����� : " + min);
		
	
	}

}

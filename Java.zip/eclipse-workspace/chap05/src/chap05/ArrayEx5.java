package chap05;

import java.util.Scanner;

public class ArrayEx5 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("2������ ��ȯ�� 10������ �Է��ϼ��� : ");
		int num = sc.nextInt();
		int binary[] = new int[32];
		int temp = num;
		int j = 0 ;
		while(temp != 0) {
			binary[j] = temp%2;
			j++;
			temp /= 2;	
		}
		
		for(int i = binary.length-1 ; i >= 0 ; i--) {
			System.out.print(binary[i]);
		}
	
	}

}

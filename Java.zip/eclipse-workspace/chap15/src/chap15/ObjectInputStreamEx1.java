package chap15;

import java.io.*;

public class ObjectInputStreamEx1 {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("object.ser"));
		Customer c1 = (Customer)ois.readObject();
		Customer c2 = (Customer)ois.readObject();
		
		System.out.println("����1: " + c1);
		System.out.println("����2: " + c2);
	}

}
class Customer implements Serializable{
	private String name;
	private transient int age;
	public Customer(String name,int age) {
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + "]";
	}

}

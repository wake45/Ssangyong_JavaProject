package chap15;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Date;
//import java.sql.Date;

public class FileOutputStreamEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		firstMethod();
	}
	public static void firstMethod() {
		secondMethod();
	}
	private static void secondMethod() {
		try {
			throw new Exception("���� ���� ����");
		}catch(Exception e) {
			e.printStackTrace();
			try {
				FileOutputStream fos = new FileOutputStream("erere.log",true);
				fos.write(e.getMessage().getBytes());
				fos.write(("============\n\n"+(new Date()) + "\n\n").getBytes());
				e.printStackTrace(new PrintStream(fos));
				fos.write("=================\n\n".getBytes());
			}catch(IOException e1) {
				e1.printStackTrace();
			}
		}
	}
}



package chap15;

import java.io.FileReader;
import java.io.IOException;

public class FileReaderEx1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileReader fis = new FileReader("src/chap15/FileReaderEx1.java");
		System.out.println("****read() �޼��带 �̿��Ͽ� �б�");
		int data = 0;
		while((data = fis.read()) != -1) {
			System.out.print((char)data);
		}
		
		fis = new FileReader("src/chap15/FileReaderEx1.java");
		System.out.println("****read(char[] buf)�޼��带 �̿��Ͽ� �б�");
		char[] buf = new char[1024];
		
		while((data = fis.read(buf)) != -1) {
			System.out.println(new String(buf,0,data));
		}
	}

}

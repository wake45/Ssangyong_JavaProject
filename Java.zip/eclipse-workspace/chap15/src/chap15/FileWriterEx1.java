package chap15;

import java.io.*;

public class FileWriterEx1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter fos = new FileWriter("output.txt");
		fos.write('1');
		fos.write('2');
		fos.write('3');
		fos.write('a');
		fos.write('b');
		fos.write('c');
		fos.write('��');
		fos.write('��');
		fos.write('��');
		char[] buf = "�ݰ�����ϴ� ���������".toCharArray();
		fos.write(buf);
		fos.write(buf,1,6);
		System.out.println((int)'\n');
		fos.write('\n');
		fos.write("�ȳ�.");
		fos.flush();
		
	}

}

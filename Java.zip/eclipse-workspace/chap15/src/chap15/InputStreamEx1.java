package chap15;

import java.io.*;

public class InputStreamEx1 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//InputStream in = System.in; //�ѱ��� ���������ʽ�
		Reader in = new InputStreamReader(System.in);
		int data = 0;
		while((data=in.read()) != -1) {
			System.out.print((char)data);
		}
	}

}

package chap15;

import java.io.*;

public class ObjectInputStreamEx2 {

	public static void main(String[] args) throws ClassNotFoundException, IOException {
		// TODO Auto-generated method stub
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("object2.ser"));
		User c1 = (User)ois.readObject();
		User c2 = (User)ois.readObject();
		
		System.out.println("�����1 :" +c1);
		System.out.println("�����2 :" + c2);
	}

}

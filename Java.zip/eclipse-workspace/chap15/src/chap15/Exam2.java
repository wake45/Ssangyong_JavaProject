package chap15;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Exam2  {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("�����Է� ");
		String text = sc.nextLine();
		FileWriter fw = new FileWriter(text,true);
		System.out.println("�����Է� ���� exit");
		while(true) {
			String data = sc.nextLine();
			if(data.equals("exit")) {
				System.out.println("�����մϴ� "); break;
			}
			fw.write(data+"\n");
			
		}
		fw.flush();
	}

}

package chap15;

import java.io.FileInputStream;
import java.io.IOException;

public class Exam3 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream fis = new FileInputStream("bin/chap15/Exam1.class");
		
		byte[] buf = new byte[fis.available()]; // available??
		int data = fis.read();
		int cnt = 0;
		for(int i = 0 ; i < data ; i++) {
			if(++cnt % 16 == 0 ) System.out.println();
			System.out.printf("%02X" , buf[i]);
		}
	}

}

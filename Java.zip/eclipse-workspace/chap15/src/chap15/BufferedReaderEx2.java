package chap15;

import java.io.*;

public class BufferedReaderEx2 {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("src/chap15/BufferedReaderEx2.java"));
		String msg = null;
		while((msg = br.readLine())!=null) {
			System.out.println(msg);
		}

	}

}

package chap15;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Arrays;

public class DataOutputStreamEx2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ByteArrayOutputStream bos = null;
		DataOutputStream dos =null;
		byte[] result = null;
		try {
			bos = new ByteArrayOutputStream();
			dos = new DataOutputStream(bos);
			dos.writeInt(10);
			dos.writeFloat(20.0f);
			dos.writeBoolean(true);
			result = bos.toByteArray();
			String[] hex = new String[result.length];
			System.out.println("10���� : " + Arrays.toString(result));
			dos.close();
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

}
